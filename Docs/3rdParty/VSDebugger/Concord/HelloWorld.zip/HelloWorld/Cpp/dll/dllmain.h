// dllmain.h : Declaration of module class.

class CHelloWorldModule : public CAtlDllModuleT< CHelloWorldModule >
{
};

extern class CHelloWorldModule _AtlModule;
