﻿$GeneratedGuid1$    .Cosmos id
$GeneratedGuid2$    .csproj id