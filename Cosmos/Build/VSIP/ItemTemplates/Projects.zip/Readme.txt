﻿Overview of templates.

+ Cosmos
    Only generates a .Cosmos file
+ CosmosKernel (C#)
    Only generates a .csproj file
+ CosmosProject (C#)
    Generates both a .csproj and a .Cosmos file.