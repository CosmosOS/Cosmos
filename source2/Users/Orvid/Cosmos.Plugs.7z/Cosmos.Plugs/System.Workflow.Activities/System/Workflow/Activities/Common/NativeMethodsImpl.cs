namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Workflow.Activities.Common.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Workflow_Activities_Common_NativeMethodsImpl
    //{

    //    public static System.Boolean DeleteObject(System.IntPtr hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.DeleteObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetDeviceCaps(System.IntPtr hDC, System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.GetDeviceCaps' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.IntPtr hWnd, System.Int32 msg, System.IntPtr wParam, System.Workflow.Activities.Common.NativeMethods+HDITEM lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Boolean IsWindowVisible(System.IntPtr hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.IsWindowVisible' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.IntPtr hWnd, System.Int32 Msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Boolean LineTo(System.Runtime.InteropServices.HandleRef hdc, System.Int32 x, System.Int32 y)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.LineTo' has not been implemented!");
    //    }

    //    public static System.Boolean MoveToEx(System.Runtime.InteropServices.HandleRef hdc, System.Int32 x, System.Int32 y, System.Workflow.Activities.Common.NativeMethods+POINT pt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.MoveToEx' has not been implemented!");
    //    }

    //    public static System.IntPtr SelectObject(System.Runtime.InteropServices.HandleRef hdc, System.Runtime.InteropServices.HandleRef obj)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SelectObject' has not been implemented!");
    //    }

    //    public static System.IntPtr GetCurrentObject(System.Runtime.InteropServices.HandleRef hDC, System.UInt32 uObjectType)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.GetCurrentObject' has not been implemented!");
    //    }

    //    public static System.Int32 DeleteObject(System.Runtime.InteropServices.HandleRef hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.DeleteObject' has not been implemented!");
    //    }

    //    public static System.IntPtr ExtCreatePen(System.Int32 style, System.Int32 nWidth, System.Workflow.Activities.Common.NativeMethods+LOGBRUSH logbrush, System.Int32 styleArrayLength, System.Int32[] styleArray)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.ExtCreatePen' has not been implemented!");
    //    }

    //    public static System.Int32 SetWorldTransform(System.Runtime.InteropServices.HandleRef hdc, System.Workflow.Activities.Common.NativeMethods+XFORM xform)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SetWorldTransform' has not been implemented!");
    //    }

    //    public static System.Int32 SetGraphicsMode(System.Runtime.InteropServices.HandleRef hdc, System.Int32 iMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SetGraphicsMode' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.IntPtr hWnd, System.Int32 Msg, System.IntPtr wParam, System.Workflow.Activities.Common.NativeMethods+TOOLINFO* ti)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.IntPtr hWnd, System.Int32 Msg, System.IntPtr wParam, System.Workflow.Activities.Common.NativeMethods+RECT* rc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Int32 SetWindowPos(System.IntPtr hWnd, System.IntPtr hwndInsertAfter, System.Int32 x, System.Int32 y, System.Int32 width, System.Int32 height, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Activities.Common.NativeMethods.SetWindowPos' has not been implemented!");
    //    }
    //}
}
