namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Activation.Interop.SafeCloseHandleCritical), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Activation_Interop_SafeCloseHandleCriticalImpl
	{

		public static System.Boolean CloseHandle(System.IntPtr handle)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Activation.Interop.SafeCloseHandleCritical.CloseHandle' has not been implemented!");
		}
	}
}
