namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Workflow.ComponentModel.Design.Helpers), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Workflow_ComponentModel_Design_HelpersImpl
	{

		public static System.Int32 MsiGetProductInfoW(System.String szProduct, System.String szProperty, System.Text.StringBuilder lpValueBuf, System.Int32* pcchValueBuf)
		{
			throw new System.NotImplementedException("Method 'System.Workflow.ComponentModel.Design.Helpers.MsiGetProductInfoW' has not been implemented!");
		}
	}
}
