namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Workflow.ComponentModel.Design.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Workflow_ComponentModel_Design_UnsafeNativeMethodsImpl
	{

		public static System.Int32 GetWindowLong(System.IntPtr hWnd, System.Int32 nIndex)
		{
			throw new System.NotImplementedException("Method 'System.Workflow.ComponentModel.Design.UnsafeNativeMethods.GetWindowLong' has not been implemented!");
		}
	}
}
