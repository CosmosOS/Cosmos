namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.SafeCertContextHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_SafeCertContextHandleImpl
	{

		public static System.Boolean CertFreeCertificateContext(System.IntPtr pCertContext)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.SafeCertContextHandle.CertFreeCertificateContext' has not been implemented!");
		}
	}
}
