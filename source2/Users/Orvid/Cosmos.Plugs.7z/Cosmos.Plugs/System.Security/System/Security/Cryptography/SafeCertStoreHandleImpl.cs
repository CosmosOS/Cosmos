namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.SafeCertStoreHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_SafeCertStoreHandleImpl
	{

		public static System.Boolean CertCloseStore(System.IntPtr hCertStore, System.UInt32 dwFlags)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.SafeCertStoreHandle.CertCloseStore' has not been implemented!");
		}
	}
}
