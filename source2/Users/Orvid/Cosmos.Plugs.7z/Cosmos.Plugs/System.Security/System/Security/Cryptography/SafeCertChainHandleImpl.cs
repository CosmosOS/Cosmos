namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.SafeCertChainHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_SafeCertChainHandleImpl
	{

		public static System.Void CertFreeCertificateChain(System.IntPtr handle)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.SafeCertChainHandle.CertFreeCertificateChain' has not been implemented!");
		}
	}
}
