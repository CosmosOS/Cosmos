namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Device.Location.Internal.PROPVARIANT), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Device_Location_Internal_PROPVARIANTImpl
	{

		public static System.Void PropVariantClear(System.Device.Location.Internal.PROPVARIANT pvar)
		{
			throw new System.NotImplementedException("Method 'System.Device.Location.Internal.PROPVARIANT.PropVariantClear' has not been implemented!");
		}
	}
}
