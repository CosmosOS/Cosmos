namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Dynamic.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Dynamic_NativeMethodsImpl
	{

		public static System.Void VariantClear(System.IntPtr variant)
		{
			throw new System.NotImplementedException("Method 'System.Dynamic.NativeMethods.VariantClear' has not been implemented!");
		}
	}
}
