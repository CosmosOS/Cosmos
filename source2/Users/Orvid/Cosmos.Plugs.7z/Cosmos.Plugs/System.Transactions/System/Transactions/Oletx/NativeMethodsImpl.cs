namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Transactions.Oletx.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Transactions_Oletx_NativeMethodsImpl
	{

		public static System.Int32 GetNotificationFactory(System.Runtime.InteropServices.SafeHandle notificationEventHandle, System.Transactions.Oletx.IDtcProxyShimFactory* ppProxyShimFactory)
		{
			throw new System.NotImplementedException("Method 'System.Transactions.Oletx.NativeMethods.GetNotificationFactory' has not been implemented!");
		}
	}
}
