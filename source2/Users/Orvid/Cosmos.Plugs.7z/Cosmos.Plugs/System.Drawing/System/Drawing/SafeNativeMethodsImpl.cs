namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Drawing.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Drawing_SafeNativeMethodsImpl
    //{

    //    public static System.IntPtr IntCreateCompatibleBitmap(System.Runtime.InteropServices.HandleRef hDC, System.Int32 width, System.Int32 height)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCreateCompatibleBitmap' has not been implemented!");
    //    }

    //    public static System.Int32 BitBlt(System.Runtime.InteropServices.HandleRef hDC, System.Int32 x, System.Int32 y, System.Int32 nWidth, System.Int32 nHeight, System.Runtime.InteropServices.HandleRef hSrcDC, System.Int32 xSrc, System.Int32 ySrc, System.Int32 dwRop)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.BitBlt' has not been implemented!");
    //    }

    //    public static System.Int32 GetDIBits(System.Runtime.InteropServices.HandleRef hdc, System.Runtime.InteropServices.HandleRef hbm, System.Int32 arg1, System.Int32 arg2, System.IntPtr arg3, System.Drawing.NativeMethods+BITMAPINFO_FLAT* bmi, System.Int32 arg5)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetDIBits' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateDIBSection(System.Runtime.InteropServices.HandleRef hdc, System.Drawing.NativeMethods+BITMAPINFO_FLAT* bmi, System.Int32 iUsage, System.IntPtr* ppvBits, System.IntPtr hSection, System.Int32 dwOffset)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCreateDIBSection' has not been implemented!");
    //    }

    //    public static System.Int32 IntDeleteObject(System.Runtime.InteropServices.HandleRef hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntDeleteObject' has not been implemented!");
    //    }

    //    public static System.IntPtr SelectObject(System.Runtime.InteropServices.HandleRef hdc, System.Runtime.InteropServices.HandleRef obj)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.SelectObject' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateIconFromResourceEx(System.Byte* pbIconBits, System.Int32 cbIconBits, System.Boolean fIcon, System.Int32 dwVersion, System.Int32 csDesired, System.Int32 cyDesired, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCreateIconFromResourceEx' has not been implemented!");
    //    }

    //    public static System.Boolean IntDestroyIcon(System.Runtime.InteropServices.HandleRef hIcon)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntDestroyIcon' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Drawing.SafeNativeMethods+LOGFONT lf)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetSysColor(System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetSysColor' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateBitmap(System.Int32 width, System.Int32 height, System.Int32 planes, System.Int32 bpp, System.IntPtr bitmapData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCreateBitmap' has not been implemented!");
    //    }

    //    public static System.UInt32 GetPaletteEntries(System.Runtime.InteropServices.HandleRef hpal, System.Int32 iStartIndex, System.Int32 nEntries, System.Byte[] lppe)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetPaletteEntries' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalFree(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GlobalFree' has not been implemented!");
    //    }

    //    public static System.Int32 StartDoc(System.Runtime.InteropServices.HandleRef hDC, System.Drawing.SafeNativeMethods+DOCINFO lpDocInfo)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.StartDoc' has not been implemented!");
    //    }

    //    public static System.Int32 StartPage(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.StartPage' has not been implemented!");
    //    }

    //    public static System.Int32 EndPage(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.EndPage' has not been implemented!");
    //    }

    //    public static System.Int32 AbortDoc(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.AbortDoc' has not been implemented!");
    //    }

    //    public static System.Int32 EndDoc(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.EndDoc' has not been implemented!");
    //    }

    //    public static System.Boolean PrintDlg(System.Drawing.SafeNativeMethods+PRINTDLG lppd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.PrintDlg' has not been implemented!");
    //    }

    //    public static System.Boolean PrintDlg(System.Drawing.SafeNativeMethods+PRINTDLGX86 lppd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.PrintDlg' has not been implemented!");
    //    }

    //    public static System.Int32 DeviceCapabilities(System.String pDevice, System.String pPort, System.Int16 fwCapabilities, System.IntPtr pOutput, System.IntPtr pDevMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.DeviceCapabilities' has not been implemented!");
    //    }

    //    public static System.Int32 DocumentProperties(System.Runtime.InteropServices.HandleRef hwnd, System.Runtime.InteropServices.HandleRef hPrinter, System.String pDeviceName, System.IntPtr pDevModeOutput, System.Runtime.InteropServices.HandleRef pDevModeInput, System.Int32 fMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.DocumentProperties' has not been implemented!");
    //    }

    //    public static System.Int32 DocumentProperties(System.Runtime.InteropServices.HandleRef hwnd, System.Runtime.InteropServices.HandleRef hPrinter, System.String pDeviceName, System.IntPtr pDevModeOutput, System.IntPtr pDevModeInput, System.Int32 fMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.DocumentProperties' has not been implemented!");
    //    }

    //    public static System.Int32 EnumPrinters(System.Int32 flags, System.String name, System.Int32 level, System.IntPtr pPrinterEnum, System.Int32 cbBuf, System.Int32* pcbNeeded, System.Int32* pcReturned)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.EnumPrinters' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalLock(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GlobalLock' has not been implemented!");
    //    }

    //    public static System.IntPtr ResetDC(System.Runtime.InteropServices.HandleRef hDC, System.Runtime.InteropServices.HandleRef lpDevMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.ResetDC' has not been implemented!");
    //    }

    //    public static System.Boolean GlobalUnlock(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GlobalUnlock' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateRectRgn(System.Int32 x1, System.Int32 y1, System.Int32 x2, System.Int32 y2)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCreateRectRgn' has not been implemented!");
    //    }

    //    public static System.Int32 GetClipRgn(System.Runtime.InteropServices.HandleRef hDC, System.Runtime.InteropServices.HandleRef hRgn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetClipRgn' has not been implemented!");
    //    }

    //    public static System.Int32 SelectClipRgn(System.Runtime.InteropServices.HandleRef hDC, System.Runtime.InteropServices.HandleRef hRgn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.SelectClipRgn' has not been implemented!");
    //    }

    //    public static System.Int32 AddFontResourceEx(System.String lpszFilename, System.Int32 fl, System.IntPtr pdv)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.AddFontResourceEx' has not been implemented!");
    //    }

    //    public static System.Int32 ExtEscape(System.Runtime.InteropServices.HandleRef hDC, System.Int32 nEscape, System.Int32 cbInput, System.Int32* inData, System.Int32 cbOutput, System.Int32* outData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.ExtEscape' has not been implemented!");
    //    }

    //    public static System.Int32 ExtEscape(System.Runtime.InteropServices.HandleRef hDC, System.Int32 nEscape, System.Int32 cbInput, System.Byte[] inData, System.Int32 cbOutput, System.Int32* outData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.ExtEscape' has not been implemented!");
    //    }

    //    public static System.Int32 IntersectClipRect(System.Runtime.InteropServices.HandleRef hDC, System.Int32 x1, System.Int32 y1, System.Int32 x2, System.Int32 y2)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntersectClipRect' has not been implemented!");
    //    }

    //    public static System.IntPtr IntGlobalAlloc(System.Int32 uFlags, System.UIntPtr dwBytes)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntGlobalAlloc' has not been implemented!");
    //    }

    //    public static System.IntPtr IntExtractAssociatedIcon(System.Runtime.InteropServices.HandleRef hInst, System.Text.StringBuilder iconPath, System.Int32* index)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntExtractAssociatedIcon' has not been implemented!");
    //    }

    //    public static System.IntPtr IntLoadIcon(System.Runtime.InteropServices.HandleRef hInst, System.IntPtr iconId)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntLoadIcon' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCopyImage(System.Runtime.InteropServices.HandleRef hImage, System.Int32 uType, System.Int32 cxDesired, System.Int32 cyDesired, System.Int32 fuFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.IntCopyImage' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Drawing.SafeNativeMethods+BITMAP bm)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Boolean GetIconInfo(System.Runtime.InteropServices.HandleRef hIcon, System.Drawing.SafeNativeMethods+ICONINFO info)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.GetIconInfo' has not been implemented!");
    //    }

    //    public static System.Boolean DrawIconEx(System.Runtime.InteropServices.HandleRef hDC, System.Int32 x, System.Int32 y, System.Runtime.InteropServices.HandleRef hIcon, System.Int32 width, System.Int32 height, System.Int32 iStepIfAniCursor, System.Runtime.InteropServices.HandleRef hBrushFlickerFree, System.Int32 diFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.DrawIconEx' has not been implemented!");
    //    }

    //    public static System.Drawing.SafeNativeMethods+IPicture OleCreatePictureIndirect(System.Drawing.SafeNativeMethods+PICTDESC pictdesc, System.Guid* refiid, System.Boolean fOwn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Drawing.SafeNativeMethods.OleCreatePictureIndirect' has not been implemented!");
    //    }
    //}
}
