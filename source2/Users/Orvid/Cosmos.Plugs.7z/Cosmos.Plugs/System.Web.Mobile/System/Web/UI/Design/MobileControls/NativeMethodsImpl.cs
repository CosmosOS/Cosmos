namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Web.UI.Design.MobileControls.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Web_UI_Design_MobileControls_NativeMethodsImpl
	{

		public static System.Boolean GetClientRect(System.IntPtr hWnd, System.Web.UI.Design.MobileControls.NativeMethods+RECT* rect)
		{
			throw new System.NotImplementedException("Method 'System.Web.UI.Design.MobileControls.NativeMethods.GetClientRect' has not been implemented!");
		}

		public static System.Boolean GetClientRect(System.IntPtr hWnd, System.Web.UI.Design.MobileControls.NativeMethods+COMRECT rect)
		{
			throw new System.NotImplementedException("Method 'System.Web.UI.Design.MobileControls.NativeMethods.GetClientRect' has not been implemented!");
		}
	}
}
