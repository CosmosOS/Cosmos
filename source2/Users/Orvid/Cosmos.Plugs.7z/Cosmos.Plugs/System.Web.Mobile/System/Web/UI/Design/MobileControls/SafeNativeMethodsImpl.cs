namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Web.UI.Design.MobileControls.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Web_UI_Design_MobileControls_SafeNativeMethodsImpl
	{

		public static System.Boolean MessageBeep(System.Int32 type)
		{
			throw new System.NotImplementedException("Method 'System.Web.UI.Design.MobileControls.SafeNativeMethods.MessageBeep' has not been implemented!");
		}
	}
}
