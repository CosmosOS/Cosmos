namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Design.Util), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Design_NativeMethods+UtilImpl
	{

		public static System.Int32 RegisterWindowMessage(System.String msg)
		{
			throw new System.NotImplementedException("Method 'System.Design.NativeMethods+Util.RegisterWindowMessage' has not been implemented!");
		}
	}
}
