namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ComponentModel.Design.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ComponentModel_Design_DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethodsImpl
	{

		public static System.IntPtr GetWindowLong(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.GetWindowLong' has not been implemented!");
		}

		public static System.IntPtr SetWindowLong(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Runtime.InteropServices.HandleRef dwNewLong)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.SetWindowLong' has not been implemented!");
		}

		public static System.Int32 MsgWaitForMultipleObjectsEx(System.Int32 nCount, System.IntPtr pHandles, System.Int32 dwMilliseconds, System.Int32 dwWakeMask, System.Int32 dwFlags)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.MsgWaitForMultipleObjectsEx' has not been implemented!");
		}

		public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Int32 lParam)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.SendMessage' has not been implemented!");
		}

		public static System.IntPtr GetCapture()
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.GetCapture' has not been implemented!");
		}

		public static System.IntPtr IntGetDC(System.Runtime.InteropServices.HandleRef hWnd)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.IntGetDC' has not been implemented!");
		}

		public static System.Int32 IntReleaseDC(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hDC)
		{
			throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+UnsafeNativeMethods.IntReleaseDC' has not been implemented!");
		}
	}
}
