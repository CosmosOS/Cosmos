namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ComponentModel.Design.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_ComponentModel_Design_DesignerActionPanel+EditorPropertyLine+SafeNativeMethodsImpl
    //{

    //    public static System.Boolean IntDeleteObject(System.Runtime.InteropServices.HandleRef hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.IntDeleteObject' has not been implemented!");
    //    }

    //    public static System.Boolean ReleaseCapture()
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.ReleaseCapture' has not been implemented!");
    //    }

    //    public static System.IntPtr SelectObject(System.Runtime.InteropServices.HandleRef hDC, System.Runtime.InteropServices.HandleRef hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.SelectObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetTextExtentPoint32(System.Runtime.InteropServices.HandleRef hDC, System.String str, System.Int32 len, System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+NativeMethods+SIZE size)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.GetTextExtentPoint32' has not been implemented!");
    //    }

    //    public static System.Int32 GetTextMetricsW(System.Runtime.InteropServices.HandleRef hDC, System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+NativeMethods+TEXTMETRIC* lptm)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.GetTextMetricsW' has not been implemented!");
    //    }

    //    public static System.Int32 GetTextMetricsA(System.Runtime.InteropServices.HandleRef hDC, System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+NativeMethods+TEXTMETRICA* lptm)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ComponentModel.Design.DesignerActionPanel+EditorPropertyLine+SafeNativeMethods.GetTextMetricsA' has not been implemented!");
    //    }
    //}
}
