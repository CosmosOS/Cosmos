namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Internal.Performance.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Internal_Performance_CodeMarkers+NativeMethodsImpl
	{

		public static System.Void DllPerfCodeMarker(System.Int32 nTimerID, System.Byte[] aUserParams, System.Int32 cbParams)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Internal.Performance.CodeMarkers+NativeMethods.DllPerfCodeMarker' has not been implemented!");
		}

		public static System.UInt16 FindAtom(System.String lpString)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Internal.Performance.CodeMarkers+NativeMethods.FindAtom' has not been implemented!");
		}
	}
}
