namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IdentityModel.SafeFreeCertContext), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IdentityModel_SafeFreeCertContextImpl
	{

		public static System.Boolean CertFreeCertificateContext(System.IntPtr certContext)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.SafeFreeCertContext.CertFreeCertificateContext' has not been implemented!");
		}
	}
}
