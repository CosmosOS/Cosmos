namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IO.Log.SafeArchiveContext), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IO_Log_SafeArchiveContextImpl
	{

		public static System.Boolean TerminateLogArchive(System.IntPtr ptr)
		{
			throw new System.NotImplementedException("Method 'System.IO.Log.SafeArchiveContext.TerminateLogArchive' has not been implemented!");
		}
	}
}
