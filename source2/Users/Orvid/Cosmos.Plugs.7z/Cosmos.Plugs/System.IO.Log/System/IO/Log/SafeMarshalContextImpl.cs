namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IO.Log.SafeMarshalContext), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IO_Log_SafeMarshalContextImpl
	{

		public static System.Boolean DeleteLogMarshallingArea(System.IntPtr ptr)
		{
			throw new System.NotImplementedException("Method 'System.IO.Log.SafeMarshalContext.DeleteLogMarshallingArea' has not been implemented!");
		}
	}
}
