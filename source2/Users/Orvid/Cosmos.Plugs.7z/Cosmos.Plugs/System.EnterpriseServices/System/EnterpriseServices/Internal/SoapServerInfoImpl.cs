namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.EnterpriseServices.Internal.SoapServerInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_EnterpriseServices_Internal_SoapServerInfoImpl
	{

		public static System.UInt32 GetSystemDirectory(System.Text.StringBuilder lpBuf, System.UInt32 uSize)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.SoapServerInfo.GetSystemDirectory' has not been implemented!");
		}
	}
}
