namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.EnterpriseServices.Internal.SoapClientImport), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_EnterpriseServices_Internal_SoapClientImportImpl
	{

		public static System.UInt32 GetSystemDirectory(System.Text.StringBuilder lpBuf, System.UInt32 uSize)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.SoapClientImport.GetSystemDirectory' has not been implemented!");
		}
	}
}
