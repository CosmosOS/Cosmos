namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.EnterpriseServices.Internal.AssemblyManager), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_EnterpriseServices_Internal_AssemblyManagerImpl
	{

		public static System.Boolean CopyFile(System.String source, System.String dest, System.Boolean failifexists)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.AssemblyManager.CopyFile' has not been implemented!");
		}
	}
}
