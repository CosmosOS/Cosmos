namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.EnterpriseServices.Internal.GenerateMetadata), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_EnterpriseServices_Internal_GenerateMetadataImpl
	{

		public static System.Int32 SearchPath(System.String path, System.String fileName, System.String extension, System.Int32 numBufferChars, System.String buffer, System.Int32[] filePart)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.GenerateMetadata.SearchPath' has not been implemented!");
		}
	}
}
