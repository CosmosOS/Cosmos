namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.EnterpriseServices.Internal.Publish), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_EnterpriseServices_Internal_PublishImpl
	{

		public static System.Int32 CreateAssemblyCache(System.EnterpriseServices.Internal.IAssemblyCache* ppAsmCache, System.UInt32 dwReserved)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.Publish.CreateAssemblyCache' has not been implemented!");
		}

		public static System.UInt32 GetSystemDirectory(System.Text.StringBuilder lpBuf, System.UInt32 uSize)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.Publish.GetSystemDirectory' has not been implemented!");
		}

		public static System.Int32 LoadTypeLib(System.String file, System.Runtime.InteropServices.ComTypes.ITypeLib* tlib)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.Publish.LoadTypeLib' has not been implemented!");
		}

		public static System.IntPtr LoadLibrary(System.String filename)
		{
			throw new System.NotImplementedException("Method 'System.EnterpriseServices.Internal.Publish.LoadLibrary' has not been implemented!");
		}
	}
}
