namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Transactions.Wsat.Clusters.SafeHCluster), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Transactions_Wsat_Clusters_SafeHClusterImpl
	{

		public static System.Boolean CloseCluster(System.IntPtr hCluster)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Transactions.Wsat.Clusters.SafeHCluster.CloseCluster' has not been implemented!");
		}
	}
}
