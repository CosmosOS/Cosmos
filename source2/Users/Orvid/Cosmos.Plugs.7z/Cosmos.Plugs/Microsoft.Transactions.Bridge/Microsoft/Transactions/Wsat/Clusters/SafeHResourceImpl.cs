namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Transactions.Wsat.Clusters.SafeHResource), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Transactions_Wsat_Clusters_SafeHResourceImpl
	{

		public static System.Boolean CloseClusterResource(System.IntPtr hResource)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Transactions.Wsat.Clusters.SafeHResource.CloseClusterResource' has not been implemented!");
		}
	}
}
