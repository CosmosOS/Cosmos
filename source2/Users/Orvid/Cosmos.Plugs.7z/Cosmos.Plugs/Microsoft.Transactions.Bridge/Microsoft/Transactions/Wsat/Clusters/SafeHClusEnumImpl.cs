namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Transactions.Wsat.Clusters.SafeHClusEnum), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Transactions_Wsat_Clusters_SafeHClusEnumImpl
	{

		public static System.UInt32 ClusterCloseEnum(System.IntPtr hEnum)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Transactions.Wsat.Clusters.SafeHClusEnum.ClusterCloseEnum' has not been implemented!");
		}
	}
}
