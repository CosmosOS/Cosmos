namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Workflow.Runtime.DebugEngine.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Workflow_Runtime_DebugEngine_NativeMethodsImpl
    //{

    //    public static System.IntPtr GetCurrentProcess()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.GetCurrentProcess' has not been implemented!");
    //    }

    //    public static System.Boolean RevertToSelf()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.RevertToSelf' has not been implemented!");
    //    }

    //    public static System.Boolean OpenProcessToken(System.IntPtr ProcessHandle, System.UInt32 DesiredAccess, System.IntPtr* TokenHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.OpenProcessToken' has not been implemented!");
    //    }

    //    public static System.Boolean GetKernelObjectSecurity(System.IntPtr Handle, System.Workflow.Runtime.DebugEngine.NativeMethods+SECURITY_INFORMATION RequestedInformation, System.IntPtr pSecurityDescriptor, System.UInt32 nLength, System.UInt32* lpnLengthNeeded)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.GetKernelObjectSecurity' has not been implemented!");
    //    }

    //    public static System.Boolean SetKernelObjectSecurity(System.IntPtr Handle, System.Workflow.Runtime.DebugEngine.NativeMethods+SECURITY_INFORMATION SecurityInformation, System.IntPtr SecurityDescriptor)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.SetKernelObjectSecurity' has not been implemented!");
    //    }

    //    public static System.Boolean CloseHandle(System.IntPtr hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.CloseHandle' has not been implemented!");
    //    }

    //    public static System.Int32 GetCurrentThreadId()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Workflow.Runtime.DebugEngine.NativeMethods.GetCurrentThreadId' has not been implemented!");
    //    }
    //}
}
