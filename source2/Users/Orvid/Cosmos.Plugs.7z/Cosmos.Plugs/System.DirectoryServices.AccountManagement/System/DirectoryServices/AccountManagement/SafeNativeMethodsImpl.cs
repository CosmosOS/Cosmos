namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.DirectoryServices.AccountManagement.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_DirectoryServices_AccountManagement_SafeNativeMethodsImpl
	{

		public static System.Int32 GetCurrentThreadId()
		{
			throw new System.NotImplementedException("Method 'System.DirectoryServices.AccountManagement.SafeNativeMethods.GetCurrentThreadId' has not been implemented!");
		}

		public static System.Int32 LsaNtStatusToWinError(System.Int32 ntStatus)
		{
			throw new System.NotImplementedException("Method 'System.DirectoryServices.AccountManagement.SafeNativeMethods.LsaNtStatusToWinError' has not been implemented!");
		}
	}
}
