namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Globalization.CultureAndRegionInfoBuilder), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Globalization_CultureAndRegionInfoBuilderImpl
	{

		public static System.Int32 GetSystemWindowsDirectory(System.Text.StringBuilder sb, System.Int32 length)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.CultureAndRegionInfoBuilder.GetSystemWindowsDirectory' has not been implemented!");
		}
	}
}
