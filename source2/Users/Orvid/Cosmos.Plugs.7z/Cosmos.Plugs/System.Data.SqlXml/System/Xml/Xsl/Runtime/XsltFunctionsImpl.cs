namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Xml.Xsl.Runtime.XsltFunctions), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Xml_Xsl_Runtime_XsltFunctionsImpl
	{

		public static System.Int32 GetDateFormat(System.Int32 locale, System.UInt32 dwFlags, System.Xml.Xsl.Runtime.XsltFunctions+SystemTime* sysTime, System.String format, System.Text.StringBuilder sb, System.Int32 sbSize)
		{
			throw new System.NotImplementedException("Method 'System.Xml.Xsl.Runtime.XsltFunctions.GetDateFormat' has not been implemented!");
		}

		public static System.Int32 GetTimeFormat(System.Int32 locale, System.UInt32 dwFlags, System.Xml.Xsl.Runtime.XsltFunctions+SystemTime* sysTime, System.String format, System.Text.StringBuilder sb, System.Int32 sbSize)
		{
			throw new System.NotImplementedException("Method 'System.Xml.Xsl.Runtime.XsltFunctions.GetTimeFormat' has not been implemented!");
		}
	}
}
