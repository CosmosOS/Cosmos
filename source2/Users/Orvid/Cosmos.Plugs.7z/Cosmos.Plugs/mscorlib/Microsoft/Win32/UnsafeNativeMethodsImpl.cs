namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class Microsoft_Win32_UnsafeNativeMethodsImpl
    //{

    //    public static System.Int32 GetTimeZoneInformation(Microsoft.Win32.Win32Native+TimeZoneInformation* lpTimeZoneInformation)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetTimeZoneInformation' has not been implemented!");
    //    }

    //    public static System.Int32 GetDynamicTimeZoneInformation(Microsoft.Win32.Win32Native+DynamicTimeZoneInformation* lpDynamicTimeZoneInformation)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetDynamicTimeZoneInformation' has not been implemented!");
    //    }

    //    public static System.Boolean GetFileMUIPath(System.Int32 flags, System.String filePath, System.Text.StringBuilder language, System.Int32* languageLength, System.Text.StringBuilder fileMuiPath, System.Int32* fileMuiPathLength, System.Int64* enumerator)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetFileMUIPath' has not been implemented!");
    //    }

    //    public static System.Int32 LoadString(Microsoft.Win32.SafeLibraryHandle handle, System.Int32 id, System.Text.StringBuilder buffer, System.Int32 bufferLength)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.LoadString' has not been implemented!");
    //    }

    //    public static Microsoft.Win32.SafeLibraryHandle LoadLibraryEx(System.String libFilename, System.IntPtr reserved, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.LoadLibraryEx' has not been implemented!");
    //    }

    //    public static System.Boolean FreeLibrary(System.IntPtr hModule)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.FreeLibrary' has not been implemented!");
    //    }

    //    public static System.UInt32 EventRegister(System.Guid* providerId, Microsoft.Win32.UnsafeNativeMethods+EtwEnableCallback enableCallback, System.Void* callbackContext, System.Int64* registrationHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventRegister' has not been implemented!");
    //    }

    //    public static System.Int32 EventUnregister(System.Int64 registrationHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventUnregister' has not been implemented!");
    //    }

    //    public static System.UInt32 EventWrite(System.Int64 registrationHandle, System.Diagnostics.Eventing.EventDescriptorInternal* eventDescriptor, System.UInt32 userDataCount, System.Void* userData)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventWrite' has not been implemented!");
    //    }

    //    public static System.UInt32 EventWrite(System.Int64 registrationHandle, System.Diagnostics.Eventing.EventDescriptorInternal* eventDescriptor, System.UInt32 userDataCount, System.Void* userData)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventWrite' has not been implemented!");
    //    }

    //    public static System.UInt32 EventWriteTransfer(System.Int64 registrationHandle, System.Diagnostics.Eventing.EventDescriptorInternal* eventDescriptor, System.Guid* activityId, System.Guid* relatedActivityId, System.UInt32 userDataCount, System.Void* userData)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventWriteTransfer' has not been implemented!");
    //    }

    //    public static System.UInt32 EventWriteString(System.Int64 registrationHandle, System.Byte level, System.Int64 keywords, System.Char* message)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventWriteString' has not been implemented!");
    //    }

    //    public static System.UInt32 EventActivityIdControl(System.Int32 ControlCode, System.Guid* ActivityId)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EventActivityIdControl' has not been implemented!");
    //    }
    //}
}
