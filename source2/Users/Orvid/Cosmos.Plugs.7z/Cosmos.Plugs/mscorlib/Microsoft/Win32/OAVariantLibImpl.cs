namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.OAVariantLib), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Win32_OAVariantLibImpl
	{

		public static System.Void ChangeTypeEx(System.Variant* result, System.Variant* source, System.Int32 lcid, System.IntPtr typeHandle, System.Int32 cvType, System.Int16 flags)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Win32.OAVariantLib.ChangeTypeEx' has not been implemented!");
		}
	}
}
