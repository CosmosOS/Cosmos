namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Type), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_TypeImpl
	{

		public static System.RuntimeType GetTypeFromHandleUnsafe(System.IntPtr handle)
		{
			throw new System.NotImplementedException("Method 'System.Type.GetTypeFromHandleUnsafe' has not been implemented!");
		}

		public static System.Type GetTypeFromHandle(System.RuntimeTypeHandle handle)
		{
			throw new System.NotImplementedException("Method 'System.Type.GetTypeFromHandle' has not been implemented!");
		}

		public static System.Boolean op_Equality(System.Type left, System.Type right)
		{
			throw new System.NotImplementedException("Method 'System.Type.op_Equality' has not been implemented!");
		}

		public static System.Boolean op_Inequality(System.Type left, System.Type right)
		{
			throw new System.NotImplementedException("Method 'System.Type.op_Inequality' has not been implemented!");
		}
	}
}
