namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.MarshalByRefObject), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_MarshalByRefObjectImpl
	{

		public static System.IntPtr GetComIUnknown(System.MarshalByRefObject o)
		{
			throw new System.NotImplementedException("Method 'System.MarshalByRefObject.GetComIUnknown' has not been implemented!");
		}
	}
}
