namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.SafeKeyHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_SafeKeyHandleImpl
	{

		public static System.Void FreeKey(System.IntPtr pKeyCotext)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.SafeKeyHandle.FreeKey' has not been implemented!");
		}
	}
}
