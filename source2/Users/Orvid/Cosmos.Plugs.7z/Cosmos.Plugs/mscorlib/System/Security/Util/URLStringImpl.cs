namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Util.URLString), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Util_URLStringImpl
	{

		public static System.Void GetDeviceName(System.String driveLetter, System.Runtime.CompilerServices.StringHandleOnStack retDeviceName)
		{
			throw new System.NotImplementedException("Method 'System.Security.Util.URLString.GetDeviceName' has not been implemented!");
		}
	}
}
