namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.SafeBSTRHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_SafeBSTRHandleImpl
	{

		public static System.Security.SafeBSTRHandle SysAllocStringLen(System.String src, System.UInt32 len)
		{
			throw new System.NotImplementedException("Method 'System.Security.SafeBSTRHandle.SysAllocStringLen' has not been implemented!");
		}
	}
}
