namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Util.StringExpressionSet), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Util_StringExpressionSetImpl
	{

		public static System.Void GetLongPathName(System.String path, System.Runtime.CompilerServices.StringHandleOnStack retLongPath)
		{
			throw new System.NotImplementedException("Method 'System.Security.Util.StringExpressionSet.GetLongPathName' has not been implemented!");
		}
	}
}
