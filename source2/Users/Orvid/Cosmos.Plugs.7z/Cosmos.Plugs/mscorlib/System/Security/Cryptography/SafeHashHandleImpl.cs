namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.SafeHashHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_SafeHashHandleImpl
	{

		public static System.Void FreeHash(System.IntPtr pHashContext)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.SafeHashHandle.FreeHash' has not been implemented!");
		}
	}
}
