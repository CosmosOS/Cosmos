namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.X509Certificates.SafeCertContextHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_X509Certificates_SafeCertContextHandleImpl
	{

		public static System.Void _FreePCertContext(System.IntPtr pCert)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.X509Certificates.SafeCertContextHandle._FreePCertContext' has not been implemented!");
		}
	}
}
