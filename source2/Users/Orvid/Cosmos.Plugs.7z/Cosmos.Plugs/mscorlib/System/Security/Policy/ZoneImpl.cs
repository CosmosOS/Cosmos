namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Policy.Zone), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Policy_ZoneImpl
	{

		public static System.Security.SecurityZone _CreateFromUrl(System.String url)
		{
			throw new System.NotImplementedException("Method 'System.Security.Policy.Zone._CreateFromUrl' has not been implemented!");
		}
	}
}
