namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Cryptography.X509Certificates.SafeCertStoreHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Cryptography_X509Certificates_SafeCertStoreHandleImpl
	{

		public static System.Void _FreeCertStoreContext(System.IntPtr hCertStore)
		{
			throw new System.NotImplementedException("Method 'System.Security.Cryptography.X509Certificates.SafeCertStoreHandle._FreeCertStoreContext' has not been implemented!");
		}
	}
}
