namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.FrameSecurityDescriptor), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_FrameSecurityDescriptorImpl
	{

		public static System.Void IncrementOverridesCount()
		{
			throw new System.NotImplementedException("Method 'System.Security.FrameSecurityDescriptor.IncrementOverridesCount' has not been implemented!");
		}

		public static System.Void DecrementOverridesCount()
		{
			throw new System.NotImplementedException("Method 'System.Security.FrameSecurityDescriptor.DecrementOverridesCount' has not been implemented!");
		}

		public static System.Void IncrementAssertCount()
		{
			throw new System.NotImplementedException("Method 'System.Security.FrameSecurityDescriptor.IncrementAssertCount' has not been implemented!");
		}

		public static System.Void DecrementAssertCount()
		{
			throw new System.NotImplementedException("Method 'System.Security.FrameSecurityDescriptor.DecrementAssertCount' has not been implemented!");
		}
	}
}
