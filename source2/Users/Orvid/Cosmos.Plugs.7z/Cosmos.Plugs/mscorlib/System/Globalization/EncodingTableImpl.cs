namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Globalization.EncodingTable), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Globalization_EncodingTableImpl
	{

		public static System.Byte* nativeCreateOpenFileMapping(System.String inSectionName, System.Int32 inBytesToAllocate, System.IntPtr* mappedFileHandle)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.EncodingTable.nativeCreateOpenFileMapping' has not been implemented!");
		}

		public static System.Globalization.InternalEncodingDataItem* GetEncodingData()
		{
			throw new System.NotImplementedException("Method 'System.Globalization.EncodingTable.GetEncodingData' has not been implemented!");
		}

		public static System.Int32 GetNumEncodingItems()
		{
			throw new System.NotImplementedException("Method 'System.Globalization.EncodingTable.GetNumEncodingItems' has not been implemented!");
		}

		public static System.Globalization.InternalCodePageDataItem* GetCodePageData()
		{
			throw new System.NotImplementedException("Method 'System.Globalization.EncodingTable.GetCodePageData' has not been implemented!");
		}
	}
}
