namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Globalization.TextInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Globalization_TextInfoImpl
	{

		public static System.Char InternalChangeCaseChar(System.IntPtr handle, System.String localeName, System.Char ch, System.Boolean isToUpper)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.TextInfo.InternalChangeCaseChar' has not been implemented!");
		}

		public static System.Int32 InternalCompareStringOrdinalIgnoreCase(System.String string1, System.Int32 index1, System.String string2, System.Int32 index2, System.Int32 length1, System.Int32 length2)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.TextInfo.InternalCompareStringOrdinalIgnoreCase' has not been implemented!");
		}

		public static System.String InternalChangeCaseString(System.IntPtr handle, System.String localeName, System.String str, System.Boolean isToUpper)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.TextInfo.InternalChangeCaseString' has not been implemented!");
		}

		public static System.Int32 InternalGetCaseInsHash(System.IntPtr handle, System.String localeName, System.String str)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.TextInfo.InternalGetCaseInsHash' has not been implemented!");
		}
	}
}
