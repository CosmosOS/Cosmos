namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Globalization.CharUnicodeInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Globalization_CharUnicodeInfoImpl
	{

		public static System.Void nativeInitTable(System.Byte* bytePtr)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.CharUnicodeInfo.nativeInitTable' has not been implemented!");
		}
	}
}
