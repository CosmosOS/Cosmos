namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Globalization.CalendarData), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Globalization_CalendarDataImpl
	{

		public static System.Int32 nativeGetCalendars(System.String localeName, System.Boolean useUserOverride, System.Int32[] calendars)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.CalendarData.nativeGetCalendars' has not been implemented!");
		}

		public static System.Boolean nativeGetCalendarData(System.Globalization.CalendarData data, System.String localeName, System.Int32 calendar)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.CalendarData.nativeGetCalendarData' has not been implemented!");
		}

		public static System.Int32 nativeGetTwoDigitYearMax(System.Int32 calID)
		{
			throw new System.NotImplementedException("Method 'System.Globalization.CalendarData.nativeGetTwoDigitYearMax' has not been implemented!");
		}
	}
}
