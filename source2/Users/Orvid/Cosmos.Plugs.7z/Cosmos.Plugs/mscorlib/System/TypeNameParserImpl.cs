namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.TypeNameParser), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_TypeNameParserImpl
	{

		public static System.Void _CreateTypeNameParser(System.String typeName, System.Runtime.CompilerServices.ObjectHandleOnStack retHandle, System.Boolean throwOnError)
		{
			throw new System.NotImplementedException("Method 'System.TypeNameParser._CreateTypeNameParser' has not been implemented!");
		}

		public static System.Void _GetNames(System.SafeTypeNameParserHandle pTypeNameParser, System.Runtime.CompilerServices.ObjectHandleOnStack retArray)
		{
			throw new System.NotImplementedException("Method 'System.TypeNameParser._GetNames' has not been implemented!");
		}

		public static System.Void _GetTypeArguments(System.SafeTypeNameParserHandle pTypeNameParser, System.Runtime.CompilerServices.ObjectHandleOnStack retArray)
		{
			throw new System.NotImplementedException("Method 'System.TypeNameParser._GetTypeArguments' has not been implemented!");
		}

		public static System.Void _GetModifiers(System.SafeTypeNameParserHandle pTypeNameParser, System.Runtime.CompilerServices.ObjectHandleOnStack retArray)
		{
			throw new System.NotImplementedException("Method 'System.TypeNameParser._GetModifiers' has not been implemented!");
		}

		public static System.Void _GetAssemblyName(System.SafeTypeNameParserHandle pTypeNameParser, System.Runtime.CompilerServices.StringHandleOnStack retString)
		{
			throw new System.NotImplementedException("Method 'System.TypeNameParser._GetAssemblyName' has not been implemented!");
		}
	}
}
