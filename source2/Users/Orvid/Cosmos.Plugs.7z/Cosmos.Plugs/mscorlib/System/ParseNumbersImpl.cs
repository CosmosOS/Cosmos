namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ParseNumbers), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ParseNumbersImpl
	{

		public static System.Int64 StringToLong(System.String s, System.Int32 radix, System.Int32 flags, System.Int32* currPos)
		{
			throw new System.NotImplementedException("Method 'System.ParseNumbers.StringToLong' has not been implemented!");
		}

		public static System.Int32 StringToInt(System.String s, System.Int32 radix, System.Int32 flags, System.Int32* currPos)
		{
			throw new System.NotImplementedException("Method 'System.ParseNumbers.StringToInt' has not been implemented!");
		}

		public static System.String IntToString(System.Int32 l, System.Int32 radix, System.Int32 width, System.Char paddingChar, System.Int32 flags)
		{
			throw new System.NotImplementedException("Method 'System.ParseNumbers.IntToString' has not been implemented!");
		}

		public static System.String LongToString(System.Int64 l, System.Int32 radix, System.Int32 width, System.Char paddingChar, System.Int32 flags)
		{
			throw new System.NotImplementedException("Method 'System.ParseNumbers.LongToString' has not been implemented!");
		}
	}
}
