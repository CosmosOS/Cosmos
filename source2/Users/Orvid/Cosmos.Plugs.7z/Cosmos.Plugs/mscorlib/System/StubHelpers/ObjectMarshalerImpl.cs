namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.StubHelpers.ObjectMarshaler), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_StubHelpers_ObjectMarshalerImpl
	{

		public static System.Void ConvertToNative(System.Object objSrc, System.IntPtr pDstVariant)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ObjectMarshaler.ConvertToNative' has not been implemented!");
		}

		public static System.Object ConvertToManaged(System.IntPtr pSrcVariant)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ObjectMarshaler.ConvertToManaged' has not been implemented!");
		}

		public static System.Void ClearNative(System.IntPtr pVariant)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ObjectMarshaler.ClearNative' has not been implemented!");
		}
	}
}
