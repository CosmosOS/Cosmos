namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.StubHelpers.InterfaceMarshaler), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_StubHelpers_InterfaceMarshalerImpl
	{

		public static System.IntPtr ConvertToNative(System.Object objSrc, System.IntPtr itfMT, System.IntPtr classMT, System.Int32 flags)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.InterfaceMarshaler.ConvertToNative' has not been implemented!");
		}

		public static System.Object ConvertToManaged(System.IntPtr pUnk, System.IntPtr itfMT, System.IntPtr classMT, System.Int32 flags)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.InterfaceMarshaler.ConvertToManaged' has not been implemented!");
		}

		public static System.Void ClearNative(System.IntPtr pUnk)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.InterfaceMarshaler.ClearNative' has not been implemented!");
		}
	}
}
