namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.StubHelpers.ValueClassMarshaler), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_StubHelpers_ValueClassMarshalerImpl
	{

		public static System.Void ConvertToNative(System.IntPtr dst, System.IntPtr src, System.IntPtr pMT, System.StubHelpers.CleanupWorkList* pCleanupWorkList)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ValueClassMarshaler.ConvertToNative' has not been implemented!");
		}

		public static System.Void ConvertToManaged(System.IntPtr dst, System.IntPtr src, System.IntPtr pMT)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ValueClassMarshaler.ConvertToManaged' has not been implemented!");
		}

		public static System.Void ClearNative(System.IntPtr dst, System.IntPtr pMT)
		{
			throw new System.NotImplementedException("Method 'System.StubHelpers.ValueClassMarshaler.ClearNative' has not been implemented!");
		}
	}
}
