namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.Remoting.Channels.ChannelServices), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_Remoting_Channels_ChannelServicesImpl
	{

		public static System.Runtime.Remoting.Channels.Perf_Contexts* GetPrivateContextsPerfCounters()
		{
			throw new System.NotImplementedException("Method 'System.Runtime.Remoting.Channels.ChannelServices.GetPrivateContextsPerfCounters' has not been implemented!");
		}
	}
}
