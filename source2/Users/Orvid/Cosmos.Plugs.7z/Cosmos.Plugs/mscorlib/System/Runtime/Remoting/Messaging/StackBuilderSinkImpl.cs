namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.Remoting.Messaging.StackBuilderSink), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_Remoting_Messaging_StackBuilderSinkImpl
	{

		public static System.Object _PrivateProcessMessage(System.Runtime.Remoting.Messaging.StackBuilderSink aThis, System.IntPtr md, System.Object[] args, System.Object server, System.Int32 methodPtr, System.Boolean fExecuteInContext, System.Object[]* outArgs)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.Remoting.Messaging.StackBuilderSink._PrivateProcessMessage' has not been implemented!");
		}
	}
}
