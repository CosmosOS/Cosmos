namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.InteropServices.ArrayWithOffset), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_InteropServices_ArrayWithOffsetImpl
	{

		public static System.Int32 CalculateCount(ref System.Runtime.InteropServices.ArrayWithOffset aThis)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.InteropServices.ArrayWithOffset.CalculateCount' has not been implemented!");
		}
	}
}
