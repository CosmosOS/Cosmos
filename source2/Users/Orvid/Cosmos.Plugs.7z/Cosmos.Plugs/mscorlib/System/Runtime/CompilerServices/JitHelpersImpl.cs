namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.CompilerServices.JitHelpers), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_CompilerServices_JitHelpersImpl
	{

		public static System.Void UnsafeSetArrayElement(System.Object[] target, System.Int32 index, System.Object element)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.CompilerServices.JitHelpers.UnsafeSetArrayElement' has not been implemented!");
		}

		public static System.Runtime.CompilerServices.PinningHelper GetPinningHelper(System.Object o)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.CompilerServices.JitHelpers.GetPinningHelper' has not been implemented!");
		}
	}
}
