namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.InteropServices.CriticalHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_InteropServices_CriticalHandleImpl
	{

		public static System.Void FireCustomerDebugProbe(System.Runtime.InteropServices.CriticalHandle aThis)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.InteropServices.CriticalHandle.FireCustomerDebugProbe' has not been implemented!");
		}
	}
}
