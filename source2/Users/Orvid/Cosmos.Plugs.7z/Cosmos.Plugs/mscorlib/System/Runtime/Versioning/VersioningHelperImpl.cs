namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.Versioning.VersioningHelper), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_Versioning_VersioningHelperImpl
	{

		public static System.Int32 GetRuntimeId()
		{
			throw new System.NotImplementedException("Method 'System.Runtime.Versioning.VersioningHelper.GetRuntimeId' has not been implemented!");
		}
	}
}
