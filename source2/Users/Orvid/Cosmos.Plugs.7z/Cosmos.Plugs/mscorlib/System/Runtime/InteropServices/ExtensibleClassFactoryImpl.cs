namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.InteropServices.ExtensibleClassFactory), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_InteropServices_ExtensibleClassFactoryImpl
	{

		public static System.Void RegisterObjectCreationCallback(System.Runtime.InteropServices.ObjectCreationDelegate callback)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.InteropServices.ExtensibleClassFactory.RegisterObjectCreationCallback' has not been implemented!");
		}
	}
}
