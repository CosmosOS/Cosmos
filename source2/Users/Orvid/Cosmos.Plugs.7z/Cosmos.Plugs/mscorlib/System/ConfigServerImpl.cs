namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ConfigServer), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ConfigServerImpl
	{

		public static System.Void RunParser(System.IConfigHandler factory, System.String fileName)
		{
			throw new System.NotImplementedException("Method 'System.ConfigServer.RunParser' has not been implemented!");
		}
	}
}
