namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.SizedReference), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_SizedReferenceImpl
	{

		public static System.IntPtr CreateSizedRef(System.Object o)
		{
			throw new System.NotImplementedException("Method 'System.SizedReference.CreateSizedRef' has not been implemented!");
		}

		public static System.Void FreeSizedRef(System.IntPtr h)
		{
			throw new System.NotImplementedException("Method 'System.SizedReference.FreeSizedRef' has not been implemented!");
		}

		public static System.Object GetTargetOfSizedRef(System.IntPtr h)
		{
			throw new System.NotImplementedException("Method 'System.SizedReference.GetTargetOfSizedRef' has not been implemented!");
		}

		public static System.Int64 GetApproximateSizeOfSizedRef(System.IntPtr h)
		{
			throw new System.NotImplementedException("Method 'System.SizedReference.GetApproximateSizeOfSizedRef' has not been implemented!");
		}
	}
}
