namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.BCLDebug), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_BCLDebugImpl
	{

		public static System.Int32 GetRegistryLoggingValues(System.Boolean* loggingEnabled, System.Boolean* logToConsole, System.Int32* logLevel, System.Boolean* perfWarnings, System.Boolean* correctnessWarnings, System.Boolean* safeHandleStackTraces)
		{
			throw new System.NotImplementedException("Method 'System.BCLDebug.GetRegistryLoggingValues' has not been implemented!");
		}
	}
}
