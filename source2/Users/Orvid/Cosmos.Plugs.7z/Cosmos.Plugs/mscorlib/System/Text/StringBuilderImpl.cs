namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Text.StringBuilder), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Text_StringBuilderImpl
	{

		public static System.Void ReplaceBufferInternal(System.Text.StringBuilder aThis, System.Char* newBuffer, System.Int32 newLength)
		{
			throw new System.NotImplementedException("Method 'System.Text.StringBuilder.ReplaceBufferInternal' has not been implemented!");
		}

		public static System.Void ReplaceBufferAnsiInternal(System.Text.StringBuilder aThis, System.SByte* newBuffer, System.Int32 newLength)
		{
			throw new System.NotImplementedException("Method 'System.Text.StringBuilder.ReplaceBufferAnsiInternal' has not been implemented!");
		}
	}
}
