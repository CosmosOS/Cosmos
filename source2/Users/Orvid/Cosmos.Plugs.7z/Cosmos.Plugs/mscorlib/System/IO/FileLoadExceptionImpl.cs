namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IO.FileLoadException), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IO_FileLoadExceptionImpl
	{

		public static System.Void GetFileLoadExceptionMessage(System.Int32 hResult, System.Runtime.CompilerServices.StringHandleOnStack retString)
		{
			throw new System.NotImplementedException("Method 'System.IO.FileLoadException.GetFileLoadExceptionMessage' has not been implemented!");
		}

		public static System.Void GetMessageForHR(System.Int32 hresult, System.Runtime.CompilerServices.StringHandleOnStack retString)
		{
			throw new System.NotImplementedException("Method 'System.IO.FileLoadException.GetMessageForHR' has not been implemented!");
		}
	}
}
