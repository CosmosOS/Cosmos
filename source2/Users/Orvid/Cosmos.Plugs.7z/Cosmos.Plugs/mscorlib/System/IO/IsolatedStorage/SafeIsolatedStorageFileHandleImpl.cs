namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IO.IsolatedStorage.SafeIsolatedStorageFileHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IO_IsolatedStorage_SafeIsolatedStorageFileHandleImpl
	{

		public static System.Void Close(System.IntPtr file)
		{
			throw new System.NotImplementedException("Method 'System.IO.IsolatedStorage.SafeIsolatedStorageFileHandle.Close' has not been implemented!");
		}
	}
}
