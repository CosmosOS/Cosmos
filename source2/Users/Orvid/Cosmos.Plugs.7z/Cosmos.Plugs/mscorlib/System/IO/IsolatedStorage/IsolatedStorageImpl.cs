namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IO.IsolatedStorage.IsolatedStorage), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IO_IsolatedStorage_IsolatedStorageImpl
	{

		public static System.Void GetCaller(System.Runtime.CompilerServices.ObjectHandleOnStack retAssembly)
		{
			throw new System.NotImplementedException("Method 'System.IO.IsolatedStorage.IsolatedStorage.GetCaller' has not been implemented!");
		}
	}
}
