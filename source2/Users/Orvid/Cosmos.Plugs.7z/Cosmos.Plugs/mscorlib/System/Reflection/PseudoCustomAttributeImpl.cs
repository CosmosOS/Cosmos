namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.PseudoCustomAttribute), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_PseudoCustomAttributeImpl
	{

		public static System.Void _GetSecurityAttributes(System.Reflection.RuntimeModule module, System.Int32 token, System.Boolean assembly, System.Object[]* securityAttributes)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.PseudoCustomAttribute._GetSecurityAttributes' has not been implemented!");
		}
	}
}
