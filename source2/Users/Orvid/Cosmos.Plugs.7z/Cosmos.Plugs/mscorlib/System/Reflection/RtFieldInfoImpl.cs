namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.RtFieldInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_RtFieldInfoImpl
	{

		public static System.Void PerformVisibilityCheckOnField(System.IntPtr field, System.Object target, System.RuntimeType declaringType, System.Reflection.FieldAttributes attr, System.UInt32 invocationFlags)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.RtFieldInfo.PerformVisibilityCheckOnField' has not been implemented!");
		}
	}
}
