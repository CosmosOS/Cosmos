namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.CustomAttributeEncodedArgument), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_CustomAttributeEncodedArgumentImpl
	{

		public static System.Void ParseAttributeArguments(System.IntPtr pCa, System.Int32 cCa, System.Reflection.CustomAttributeCtorParameter[]* CustomAttributeCtorParameters, System.Reflection.CustomAttributeNamedParameter[]* CustomAttributeTypedArgument, System.Reflection.RuntimeAssembly assembly)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.CustomAttributeEncodedArgument.ParseAttributeArguments' has not been implemented!");
		}
	}
}
