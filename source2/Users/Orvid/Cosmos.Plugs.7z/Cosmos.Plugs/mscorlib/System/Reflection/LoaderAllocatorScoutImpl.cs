namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.LoaderAllocatorScout), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_LoaderAllocatorScoutImpl
	{

		public static System.Boolean Destroy(System.IntPtr nativeLoaderAllocator)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.LoaderAllocatorScout.Destroy' has not been implemented!");
		}
	}
}
