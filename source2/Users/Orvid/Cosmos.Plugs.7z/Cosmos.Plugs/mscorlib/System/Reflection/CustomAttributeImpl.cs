namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.CustomAttribute), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_CustomAttributeImpl
	{

		public static System.Void _ParseAttributeUsageAttribute(System.IntPtr pCa, System.Int32 cCa, System.Int32* targets, System.Boolean* inherited, System.Boolean* allowMultiple)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.CustomAttribute._ParseAttributeUsageAttribute' has not been implemented!");
		}

		public static System.Object _CreateCaObject(System.Reflection.RuntimeModule pModule, System.IRuntimeMethodInfo pCtor, System.Byte** ppBlob, System.Byte* pEndBlob, System.Int32* pcNamedArgs)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.CustomAttribute._CreateCaObject' has not been implemented!");
		}

		public static System.Void _GetPropertyOrFieldData(System.Reflection.RuntimeModule pModule, System.Byte** ppBlobStart, System.Byte* pBlobEnd, System.String* name, System.Boolean* bIsProperty, System.RuntimeType* type, System.Object* value)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.CustomAttribute._GetPropertyOrFieldData' has not been implemented!");
		}
	}
}
