namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.Emit.MethodRental), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_Emit_MethodRentalImpl
	{

		public static System.Void SwapMethodBody(System.RuntimeTypeHandle cls, System.Int32 methodtoken, System.IntPtr rgIL, System.Int32 methodSize, System.Int32 flags, System.Runtime.CompilerServices.StackCrawlMarkHandle stackMark)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.MethodRental.SwapMethodBody' has not been implemented!");
		}
	}
}
