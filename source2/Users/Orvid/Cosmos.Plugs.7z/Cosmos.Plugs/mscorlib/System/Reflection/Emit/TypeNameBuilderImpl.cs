namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.Emit.TypeNameBuilder), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_Emit_TypeNameBuilderImpl
	{

		public static System.IntPtr CreateTypeNameBuilder()
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.CreateTypeNameBuilder' has not been implemented!");
		}

		public static System.Void ReleaseTypeNameBuilder(System.IntPtr pAQN)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.ReleaseTypeNameBuilder' has not been implemented!");
		}

		public static System.Void AddName(System.IntPtr tnb, System.String name)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddName' has not been implemented!");
		}

		public static System.Void ToString(System.IntPtr tnb, System.Runtime.CompilerServices.StringHandleOnStack retString)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.ToString' has not been implemented!");
		}

		public static System.Void Clear(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.Clear' has not been implemented!");
		}

		public static System.Void OpenGenericArguments(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.OpenGenericArguments' has not been implemented!");
		}

		public static System.Void CloseGenericArguments(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.CloseGenericArguments' has not been implemented!");
		}

		public static System.Void OpenGenericArgument(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.OpenGenericArgument' has not been implemented!");
		}

		public static System.Void CloseGenericArgument(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.CloseGenericArgument' has not been implemented!");
		}

		public static System.Void AddPointer(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddPointer' has not been implemented!");
		}

		public static System.Void AddByRef(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddByRef' has not been implemented!");
		}

		public static System.Void AddSzArray(System.IntPtr tnb)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddSzArray' has not been implemented!");
		}

		public static System.Void AddArray(System.IntPtr tnb, System.Int32 rank)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddArray' has not been implemented!");
		}

		public static System.Void AddAssemblySpec(System.IntPtr tnb, System.String assemblySpec)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.Emit.TypeNameBuilder.AddAssemblySpec' has not been implemented!");
		}
	}
}
