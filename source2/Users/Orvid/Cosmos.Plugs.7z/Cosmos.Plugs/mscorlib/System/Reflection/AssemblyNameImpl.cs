namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Reflection.AssemblyName), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Reflection_AssemblyNameImpl
	{

		public static System.Boolean ReferenceMatchesDefinition(System.Reflection.AssemblyName reference, System.Reflection.AssemblyName definition)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.ReferenceMatchesDefinition' has not been implemented!");
		}

		public static System.Int32 nInit(System.Reflection.AssemblyName aThis, System.Reflection.RuntimeAssembly* assembly, System.Boolean forIntrospection, System.Boolean raiseResolveEvent)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.nInit' has not been implemented!");
		}

		public static System.Reflection.AssemblyName nGetFileInformation(System.String s)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.nGetFileInformation' has not been implemented!");
		}

		public static System.String nToString(System.Reflection.AssemblyName aThis)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.nToString' has not been implemented!");
		}

		public static System.String EscapeCodeBase(System.String codeBase)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.EscapeCodeBase' has not been implemented!");
		}

		public static System.Byte[] nGetPublicKeyToken(System.Reflection.AssemblyName aThis)
		{
			throw new System.NotImplementedException("Method 'System.Reflection.AssemblyName.nGetPublicKeyToken' has not been implemented!");
		}
	}
}
