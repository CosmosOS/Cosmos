namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Currency), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_CurrencyImpl
	{

		public static System.Void FCallToDecimal(System.Decimal* result, System.Currency c)
		{
			throw new System.NotImplementedException("Method 'System.Currency.FCallToDecimal' has not been implemented!");
		}
	}
}
