namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.AppDomainSetup), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_AppDomainSetupImpl
	{

		public static System.Void UpdateContextProperty(System.IntPtr fusionContext, System.String key, System.Object value)
		{
			throw new System.NotImplementedException("Method 'System.AppDomainSetup.UpdateContextProperty' has not been implemented!");
		}
	}
}
