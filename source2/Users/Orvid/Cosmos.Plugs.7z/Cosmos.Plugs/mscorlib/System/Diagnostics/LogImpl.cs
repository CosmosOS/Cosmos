namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.Log), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Diagnostics_LogImpl
	{

		public static System.Void AddLogSwitch(System.Diagnostics.LogSwitch logSwitch)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.Log.AddLogSwitch' has not been implemented!");
		}

		public static System.Void ModifyLogSwitch(System.Int32 iNewLevel, System.String strSwitchName, System.String strParentName)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.Log.ModifyLogSwitch' has not been implemented!");
		}
	}
}
