namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.Eventing.ClassicEtw), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Diagnostics_Eventing_EventProvider+ClassicEtwImpl
    //{

    //    public static System.UInt32 RegisterTraceGuidsW(System.Diagnostics.Eventing.EventProvider+ClassicEtw+ControlCallback cbFunc, System.Void* context, System.Guid* providerGuid, System.Int32 taskGuidCount, System.Diagnostics.Eventing.EventProvider+ClassicEtw+TRACE_GUID_REGISTRATION* taskGuids, System.String mofImagePath, System.String mofResourceName, System.Int64* regHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.RegisterTraceGuidsW' has not been implemented!");
    //    }

    //    public static System.UInt32 UnregisterTraceGuids(System.Int64 regHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.UnregisterTraceGuids' has not been implemented!");
    //    }

    //    public static System.Int32 GetTraceEnableFlags(System.UInt64 traceHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.GetTraceEnableFlags' has not been implemented!");
    //    }

    //    public static System.Byte GetTraceEnableLevel(System.UInt64 traceHandle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.GetTraceEnableLevel' has not been implemented!");
    //    }

    //    public static System.Int64 GetTraceLoggerHandle(System.Diagnostics.Eventing.EventProvider+ClassicEtw+WNODE_HEADER* data)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.GetTraceLoggerHandle' has not been implemented!");
    //    }

    //    public static System.UInt32 TraceEvent(System.Int64 traceHandle, System.Diagnostics.Eventing.EventProvider+ClassicEtw+EVENT_HEADER* header)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider+ClassicEtw.TraceEvent' has not been implemented!");
    //    }
    //}
}
