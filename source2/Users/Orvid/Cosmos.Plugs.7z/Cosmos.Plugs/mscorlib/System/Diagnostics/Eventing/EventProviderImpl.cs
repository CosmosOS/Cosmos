namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.Eventing.EventProvider), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Diagnostics_Eventing_EventProviderImpl
	{

		public static System.Void ZeroMemory(System.IntPtr handle, System.Int32 length)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.Eventing.EventProvider.ZeroMemory' has not been implemented!");
		}
	}
}
