namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.Assert), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Diagnostics_AssertImpl
	{

		public static System.Int32 ShowDefaultAssertDialog(System.String conditionString, System.String message, System.String stackTrace)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.Assert.ShowDefaultAssertDialog' has not been implemented!");
		}
	}
}
