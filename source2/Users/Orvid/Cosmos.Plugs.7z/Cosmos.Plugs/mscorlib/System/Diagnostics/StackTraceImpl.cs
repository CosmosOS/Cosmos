namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.StackTrace), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Diagnostics_StackTraceImpl
	{

		public static System.Void GetStackFramesInternal(System.Diagnostics.StackFrameHelper sfh, System.Int32 iSkip, System.Exception e)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.StackTrace.GetStackFramesInternal' has not been implemented!");
		}
	}
}
