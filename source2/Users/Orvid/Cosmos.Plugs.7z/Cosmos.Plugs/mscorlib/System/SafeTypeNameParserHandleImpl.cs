namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.SafeTypeNameParserHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_SafeTypeNameParserHandleImpl
	{

		public static System.Void _ReleaseTypeNameParser(System.IntPtr pTypeNameParser)
		{
			throw new System.NotImplementedException("Method 'System.SafeTypeNameParserHandle._ReleaseTypeNameParser' has not been implemented!");
		}
	}
}
