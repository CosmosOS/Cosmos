namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Deployment.Internal.Isolation.IsolationInterop), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Deployment_Internal_Isolation_IsolationInteropImpl
    //{

    //    public static System.Object CreateActContext(System.Deployment.Internal.Isolation.IsolationInterop+CreateActContextParameters* Params)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.CreateActContext' has not been implemented!");
    //    }

    //    public static System.Object CreateCMSFromXml(System.Byte[] buffer, System.UInt32 bufferSize, System.Deployment.Internal.Isolation.IManifestParseErrorCallback Callback, System.Guid* riid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.CreateCMSFromXml' has not been implemented!");
    //    }

    //    public static System.Object ParseManifest(System.String pszManifestPath, System.Deployment.Internal.Isolation.IManifestParseErrorCallback pIManifestParseErrorCallback, System.Guid* riid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.ParseManifest' has not been implemented!");
    //    }

    //    public static System.Object GetUserStore(System.UInt32 Flags, System.IntPtr hToken, System.Guid* riid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.GetUserStore' has not been implemented!");
    //    }

    //    public static System.Deployment.Internal.Isolation.IIdentityAuthority GetIdentityAuthority()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.GetIdentityAuthority' has not been implemented!");
    //    }

    //    public static System.Deployment.Internal.Isolation.IAppIdAuthority GetAppIdAuthority()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Deployment.Internal.Isolation.IsolationInterop.GetAppIdAuthority' has not been implemented!");
    //    }
    //}
}
