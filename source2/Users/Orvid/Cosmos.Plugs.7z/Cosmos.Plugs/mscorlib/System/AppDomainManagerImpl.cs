namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.AppDomainManager), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_AppDomainManagerImpl
	{

		public static System.Void GetEntryAssembly(System.Runtime.CompilerServices.ObjectHandleOnStack retAssembly)
		{
			throw new System.NotImplementedException("Method 'System.AppDomainManager.GetEntryAssembly' has not been implemented!");
		}

		public static System.Boolean HasHost()
		{
			throw new System.NotImplementedException("Method 'System.AppDomainManager.HasHost' has not been implemented!");
		}

		public static System.Void RegisterWithHost(System.IntPtr appDomainManager)
		{
			throw new System.NotImplementedException("Method 'System.AppDomainManager.RegisterWithHost' has not been implemented!");
		}
	}
}
