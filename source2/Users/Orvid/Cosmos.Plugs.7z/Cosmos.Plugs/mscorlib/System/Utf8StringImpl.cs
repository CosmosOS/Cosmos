namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Utf8String), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Utf8StringImpl
	{

		public static System.Boolean EqualsCaseSensitive(System.Void* szLhs, System.Void* szRhs, System.Int32 cSz)
		{
			throw new System.NotImplementedException("Method 'System.Utf8String.EqualsCaseSensitive' has not been implemented!");
		}

		public static System.Boolean EqualsCaseInsensitive(System.Void* szLhs, System.Void* szRhs, System.Int32 cSz)
		{
			throw new System.NotImplementedException("Method 'System.Utf8String.EqualsCaseInsensitive' has not been implemented!");
		}

		public static System.UInt32 HashCaseInsensitive(System.Void* sz, System.Int32 cSz)
		{
			throw new System.NotImplementedException("Method 'System.Utf8String.HashCaseInsensitive' has not been implemented!");
		}
	}
}
