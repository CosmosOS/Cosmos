namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ArgIterator), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ArgIteratorImpl
	{

		public static System.Int32 GetRemainingCount(ref System.ArgIterator aThis)
		{
			throw new System.NotImplementedException("Method 'System.ArgIterator.GetRemainingCount' has not been implemented!");
		}

		public static System.Void FCallGetNextArg(ref System.ArgIterator aThis, System.Void* result)
		{
			throw new System.NotImplementedException("Method 'System.ArgIterator.FCallGetNextArg' has not been implemented!");
		}

		public static System.Void InternalGetNextArg(ref System.ArgIterator aThis, System.Void* result, System.RuntimeType rt)
		{
			throw new System.NotImplementedException("Method 'System.ArgIterator.InternalGetNextArg' has not been implemented!");
		}

		public static System.Void* _GetNextArgType(ref System.ArgIterator aThis)
		{
			throw new System.NotImplementedException("Method 'System.ArgIterator._GetNextArgType' has not been implemented!");
		}
	}
}
