namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.DateTime), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_DateTimeImpl
	{

		public static System.Int64 GetSystemTimeAsFileTime()
		{
			throw new System.NotImplementedException("Method 'System.DateTime.GetSystemTimeAsFileTime' has not been implemented!");
		}
	}
}
