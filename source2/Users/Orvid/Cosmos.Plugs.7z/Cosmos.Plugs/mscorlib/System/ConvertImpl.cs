namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Convert), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ConvertImpl
	{

		public static System.Byte[] FromBase64String(System.String s)
		{
			throw new System.NotImplementedException("Method 'System.Convert.FromBase64String' has not been implemented!");
		}

		public static System.Byte[] FromBase64CharArray(System.Char[] inArray, System.Int32 offset, System.Int32 length)
		{
			throw new System.NotImplementedException("Method 'System.Convert.FromBase64CharArray' has not been implemented!");
		}
	}
}
