namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Web.Services.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Web_Services_UnsafeNativeMethodsImpl
	{

		public static System.Int32 CoCreateInstance(System.Guid* clsid, System.Object punkOuter, System.Int32 context, System.Guid* iid, System.Object* punk)
		{
			throw new System.NotImplementedException("Method 'System.Web.Services.UnsafeNativeMethods.CoCreateInstance' has not been implemented!");
		}
	}
}
