namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Web.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Web_NativeMethodsImpl
	{

		public static System.Int32 CreateAssemblyCache(System.Web.Configuration.IAssemblyCache* ppAsmCache, System.UInt32 dwReserved)
		{
			throw new System.NotImplementedException("Method 'System.Web.NativeMethods.CreateAssemblyCache' has not been implemented!");
		}
	}
}
