namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.InfoCards.Diagnostics.SafeEventLogHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class Microsoft_InfoCards_Diagnostics_InfoCardTrace+SafeEventLogHandleImpl
    //{

    //    public static System.Boolean DeregisterEventSource(System.IntPtr eventLog)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.InfoCards.Diagnostics.InfoCardTrace+SafeEventLogHandle.DeregisterEventSource' has not been implemented!");
    //    }

    //    public static Microsoft.InfoCards.Diagnostics.InfoCardTrace+SafeEventLogHandle RegisterEventSource(System.String uncServerName, System.String sourceName)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.InfoCards.Diagnostics.InfoCardTrace+SafeEventLogHandle.RegisterEventSource' has not been implemented!");
    //    }
    //}
}
