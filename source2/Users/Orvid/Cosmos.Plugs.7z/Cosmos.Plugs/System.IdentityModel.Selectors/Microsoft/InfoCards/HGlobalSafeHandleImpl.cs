namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.InfoCards.HGlobalSafeHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_InfoCards_HGlobalSafeHandleImpl
	{

		public static System.Void ZeroMemory(System.IntPtr dest, System.Int32 size)
		{
			throw new System.NotImplementedException("Method 'Microsoft.InfoCards.HGlobalSafeHandle.ZeroMemory' has not been implemented!");
		}
	}
}
