namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IdentityModel.Selectors.NativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IdentityModel_Selectors_NativeMethodsImpl
	{

		public static System.IntPtr GetProcAddress(System.IdentityModel.Selectors.SafeLibraryHandle hModule, System.String procname)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.Selectors.NativeMethods.GetProcAddress' has not been implemented!");
		}
	}
}
