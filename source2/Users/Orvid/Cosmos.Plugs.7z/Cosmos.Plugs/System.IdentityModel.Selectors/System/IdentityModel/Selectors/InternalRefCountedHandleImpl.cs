namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IdentityModel.Selectors.InternalRefCountedHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IdentityModel_Selectors_InternalRefCountedHandleImpl
	{

		public static System.Boolean CloseCryptoHandle(System.IntPtr hKey)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.Selectors.InternalRefCountedHandle.CloseCryptoHandle' has not been implemented!");
		}
	}
}
