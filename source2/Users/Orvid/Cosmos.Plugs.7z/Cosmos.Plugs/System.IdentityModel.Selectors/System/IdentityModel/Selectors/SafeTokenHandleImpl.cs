namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IdentityModel.Selectors.SafeTokenHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IdentityModel_Selectors_SafeTokenHandleImpl
	{

		public static System.Int32 FreeToken(System.IntPtr token)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.Selectors.SafeTokenHandle.FreeToken' has not been implemented!");
		}
	}
}
