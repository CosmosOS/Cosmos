namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.IdentityModel.Selectors.SafeLibraryHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_IdentityModel_Selectors_SafeLibraryHandleImpl
	{

		public static System.IdentityModel.Selectors.SafeLibraryHandle LoadLibraryW(System.String dllname)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.Selectors.SafeLibraryHandle.LoadLibraryW' has not been implemented!");
		}

		public static System.Boolean FreeLibrary(System.IntPtr hModule)
		{
			throw new System.NotImplementedException("Method 'System.IdentityModel.Selectors.SafeLibraryHandle.FreeLibrary' has not been implemented!");
		}
	}
}
