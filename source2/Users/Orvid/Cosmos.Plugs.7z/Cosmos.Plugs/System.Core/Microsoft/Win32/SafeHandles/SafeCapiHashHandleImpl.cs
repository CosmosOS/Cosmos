namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.SafeHandles.SafeCapiHashHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Win32_SafeHandles_SafeCapiHashHandleImpl
	{

		public static System.Boolean CryptDestroyHash(System.IntPtr hHash)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Win32.SafeHandles.SafeCapiHashHandle.CryptDestroyHash' has not been implemented!");
		}
	}
}
