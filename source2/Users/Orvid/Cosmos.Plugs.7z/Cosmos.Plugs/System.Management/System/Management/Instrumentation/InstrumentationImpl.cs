namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.Instrumentation.Instrumentation), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_Instrumentation_InstrumentationImpl
	{

		public static System.Int32 GetCurrentProcessId()
		{
			throw new System.NotImplementedException("Method 'System.Management.Instrumentation.Instrumentation.GetCurrentProcessId' has not been implemented!");
		}
	}
}
