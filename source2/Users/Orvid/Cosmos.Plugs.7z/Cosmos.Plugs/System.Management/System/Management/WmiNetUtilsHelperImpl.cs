namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.WmiNetUtilsHelper), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_WmiNetUtilsHelperImpl
	{

		public static System.IntPtr LoadLibrary(System.String fileName)
		{
			throw new System.NotImplementedException("Method 'System.Management.WmiNetUtilsHelper.LoadLibrary' has not been implemented!");
		}

		public static System.IntPtr GetProcAddress(System.IntPtr hModule, System.String procname)
		{
			throw new System.NotImplementedException("Method 'System.Management.WmiNetUtilsHelper.GetProcAddress' has not been implemented!");
		}
	}
}
