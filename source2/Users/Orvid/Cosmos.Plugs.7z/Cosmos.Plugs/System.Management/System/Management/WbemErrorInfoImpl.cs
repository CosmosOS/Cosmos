namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.WbemErrorInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_WbemErrorInfoImpl
	{

		public static System.Management.IErrorInfo GetErrorInfo(System.Int32 reserved)
		{
			throw new System.NotImplementedException("Method 'System.Management.WbemErrorInfo.GetErrorInfo' has not been implemented!");
		}
	}
}
