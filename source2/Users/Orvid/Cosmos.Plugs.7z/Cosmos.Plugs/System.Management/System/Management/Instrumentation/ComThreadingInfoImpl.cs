namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.Instrumentation.ComThreadingInfo), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_Instrumentation_ComThreadingInfoImpl
	{

		public static System.Object CoGetObjectContext(System.Guid* riid)
		{
			throw new System.NotImplementedException("Method 'System.Management.Instrumentation.ComThreadingInfo.CoGetObjectContext' has not been implemented!");
		}
	}
}
