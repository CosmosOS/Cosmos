namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.ManagementScope), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_ManagementScopeImpl
	{

		public static System.Int32 RpcMgmtEnableIdleCleanup()
		{
			throw new System.NotImplementedException("Method 'System.Management.ManagementScope.RpcMgmtEnableIdleCleanup' has not been implemented!");
		}
	}
}
