namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Management.MTAHelper), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Management_MTAHelperImpl
	{

		public static System.Int32 CoGetObjectContext(System.Guid* riid, System.IntPtr* pUnk)
		{
			throw new System.NotImplementedException("Method 'System.Management.MTAHelper.CoGetObjectContext' has not been implemented!");
		}
	}
}
