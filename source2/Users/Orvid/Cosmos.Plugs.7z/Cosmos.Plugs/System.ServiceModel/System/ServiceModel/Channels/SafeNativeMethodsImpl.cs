namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Channels.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Channels_SafeNativeMethodsImpl
	{

		public static System.Void GetSystemTimeAsFileTime(System.Int64* time)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SafeNativeMethods.GetSystemTimeAsFileTime' has not been implemented!");
		}

		public static System.UInt32 GetSystemTimeAdjustment(System.Int32* adjustment, System.UInt32* increment, System.UInt32* adjustmentDisabled)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SafeNativeMethods.GetSystemTimeAdjustment' has not been implemented!");
		}
	}
}
