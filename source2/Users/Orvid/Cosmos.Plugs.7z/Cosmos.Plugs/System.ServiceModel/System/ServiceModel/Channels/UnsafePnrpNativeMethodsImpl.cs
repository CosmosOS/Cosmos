namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Channels.UnsafePnrpNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Channels_PnrpPeerResolver+UnsafePnrpNativeMethodsImpl
	{

		public static System.Int32 WSALookupServiceEnd(System.IntPtr hLookup)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSALookupServiceEnd' has not been implemented!");
		}

		public static System.Int32 WSASetService(System.ServiceModel.Channels.CriticalAllocHandle querySet, System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+WsaSetServiceOp essOperation, System.Int32 dwControlFlags)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSASetService' has not been implemented!");
		}

		public static System.Int32 WSALookupServiceNext(System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+CriticalLookupHandle hLookup, System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+WsaNspControlFlags dwControlFlags, System.Int32* lpdwBufferLength, System.IntPtr Results)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSALookupServiceNext' has not been implemented!");
		}

		public static System.Int32 WSALookupServiceBegin(System.ServiceModel.Channels.CriticalAllocHandle query, System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+WsaNspControlFlags dwControlFlags, System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+CriticalLookupHandle* hLookup)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSALookupServiceBegin' has not been implemented!");
		}

		public static System.Int32 WSAStartup(System.Int16 wVersionRequested, System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods+WsaData* lpWSAData)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSAStartup' has not been implemented!");
		}

		public static System.Int32 WSACleanup()
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSACleanup' has not been implemented!");
		}

		public static System.Int32 WSAGetLastError()
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSAGetLastError' has not been implemented!");
		}

		public static System.Int32 WSAEnumNameSpaceProviders(System.Int32* lpdwBufferLength, System.IntPtr lpnspBuffer)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.PnrpPeerResolver+UnsafePnrpNativeMethods.WSAEnumNameSpaceProviders' has not been implemented!");
		}
	}
}
