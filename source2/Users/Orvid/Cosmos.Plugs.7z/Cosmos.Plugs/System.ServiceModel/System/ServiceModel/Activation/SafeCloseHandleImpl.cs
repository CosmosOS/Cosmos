namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Activation.SafeCloseHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Activation_SafeCloseHandleImpl
	{

		public static System.Boolean CloseHandle(System.IntPtr handle)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Activation.SafeCloseHandle.CloseHandle' has not been implemented!");
		}
	}
}
