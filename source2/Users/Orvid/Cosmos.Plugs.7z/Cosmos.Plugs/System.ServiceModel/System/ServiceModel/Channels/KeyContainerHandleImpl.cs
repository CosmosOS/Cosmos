namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Channels.KeyContainerHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Channels_KeyContainerHandleImpl
	{

		public static System.Boolean CryptReleaseContext(System.IntPtr hProv, System.Int32 dwFlags)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.KeyContainerHandle.CryptReleaseContext' has not been implemented!");
		}
	}
}
