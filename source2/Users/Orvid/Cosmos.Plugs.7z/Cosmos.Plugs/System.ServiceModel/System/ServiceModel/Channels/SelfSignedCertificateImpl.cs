namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Channels.SelfSignedCertificate), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_ServiceModel_Channels_SelfSignedCertificateImpl
    //{

    //    public static System.ServiceModel.Channels.CertificateHandle CertCreateSelfSignCertificate(System.ServiceModel.Channels.KeyContainerHandle hProv, System.ServiceModel.Channels.CryptoApiBlob.InteropHelper pSubjectIssuerBlob, System.ServiceModel.Channels.SelfSignedCertificate+SelfSignFlags dwFlags, System.IntPtr pKeyProvInfo, System.IntPtr pSignatureAlgorithm, System.ServiceModel.Channels.SystemTime* pStartTime, System.ServiceModel.Channels.SystemTime* pEndTime, System.IntPtr pExtensions)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CertCreateSelfSignCertificate' has not been implemented!");
    //    }

    //    public static System.ServiceModel.Channels.CertificateStoreHandle CertOpenStore(System.IntPtr lpszStoreProvider, System.Int32 dwMsgAndCertEncodingType, System.IntPtr hCryptProv, System.Int32 dwFlags, System.IntPtr pvPara)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CertOpenStore' has not been implemented!");
    //    }

    //    public static System.Boolean CertAddCertificateContextToStore(System.ServiceModel.Channels.CertificateStoreHandle hCertStore, System.ServiceModel.Channels.CertificateHandle pCertContext, System.ServiceModel.Channels.SelfSignedCertificate+AddDisposition dwAddDisposition, System.ServiceModel.Channels.StoreCertificateHandle* ppStoreContext)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CertAddCertificateContextToStore' has not been implemented!");
    //    }

    //    public static System.Boolean CryptAcquireContext(System.ServiceModel.Channels.KeyContainerHandle* phProv, System.String pszContainer, System.String pszProvider, System.ServiceModel.Channels.SelfSignedCertificate+ProviderType dwProvType, System.ServiceModel.Channels.SelfSignedCertificate+ContextFlags dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CryptAcquireContext' has not been implemented!");
    //    }

    //    public static System.Boolean CryptGenKey(System.ServiceModel.Channels.KeyContainerHandle hProv, System.ServiceModel.Channels.SelfSignedCertificate+AlgorithmType algId, System.ServiceModel.Channels.SelfSignedCertificate+KeyFlags dwFlags, System.ServiceModel.Channels.KeyHandle* phKey)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CryptGenKey' has not been implemented!");
    //    }

    //    public static System.Boolean PFXExportCertStoreEx(System.ServiceModel.Channels.CertificateStoreHandle hStore, System.IntPtr pPFX, System.String password, System.IntPtr pvReserved, System.ServiceModel.Channels.SelfSignedCertificate+PfxExportFlags dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.PFXExportCertStoreEx' has not been implemented!");
    //    }

    //    public static System.Boolean CertSetCertificateContextProperty(System.ServiceModel.Channels.CertificateHandle context, System.Int32 propId, System.Int32 flags, System.ServiceModel.Channels.KeyHandle pv)
    //    {
    //        throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.SelfSignedCertificate.CertSetCertificateContextProperty' has not been implemented!");
    //    }
    //}
}
