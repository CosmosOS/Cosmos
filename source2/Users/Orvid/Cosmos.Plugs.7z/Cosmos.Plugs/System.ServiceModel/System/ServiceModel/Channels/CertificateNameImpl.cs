namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.ServiceModel.Channels.CertificateName), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_ServiceModel_Channels_CertificateNameImpl
	{

		public static System.Boolean CertStrToName(System.ServiceModel.Channels.CertificateName+CertEncodingType dwCertEncodingType, System.String pszX500, System.ServiceModel.Channels.CertificateName+StringType dwStrType, System.IntPtr pvReserved, System.Byte[] pbEncoded, System.Int32* pcbEncoded, System.Text.StringBuilder* ppszError)
		{
			throw new System.NotImplementedException("Method 'System.ServiceModel.Channels.CertificateName.CertStrToName' has not been implemented!");
		}
	}
}
