namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Runtime.Interop.SafeEventLogWriteHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Runtime_Interop_SafeEventLogWriteHandleImpl
	{

		public static System.Boolean DeregisterEventSource(System.IntPtr hEventLog)
		{
			throw new System.NotImplementedException("Method 'System.Runtime.Interop.SafeEventLogWriteHandle.DeregisterEventSource' has not been implemented!");
		}
	}
}
