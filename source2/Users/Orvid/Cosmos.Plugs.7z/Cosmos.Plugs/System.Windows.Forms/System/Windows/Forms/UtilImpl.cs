namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.Util), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Windows_Forms_NativeMethods+UtilImpl
	{

		public static System.Int32 lstrlen(System.String s)
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.NativeMethods+Util.lstrlen' has not been implemented!");
		}
	}
}
