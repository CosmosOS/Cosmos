namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.VARIANT), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Windows_Forms_NativeMethods+VARIANTImpl
	{

		public static System.IntPtr SysAllocString(System.String s)
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.NativeMethods+VARIANT.SysAllocString' has not been implemented!");
		}

		public static System.Void SysFreeString(System.IntPtr pbstr)
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.NativeMethods+VARIANT.SysFreeString' has not been implemented!");
		}
	}
}
