namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.ThemingScope), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Windows_Forms_UnsafeNativeMethods+ThemingScopeImpl
    //{

    //    public static System.IntPtr CreateActCtx(System.Windows.Forms.UnsafeNativeMethods+ThemingScope+ACTCTX* actctx)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+ThemingScope.CreateActCtx' has not been implemented!");
    //    }

    //    public static System.Boolean ActivateActCtx(System.IntPtr hActCtx, System.IntPtr* lpCookie)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+ThemingScope.ActivateActCtx' has not been implemented!");
    //    }

    //    public static System.Boolean DeactivateActCtx(System.Int32 dwFlags, System.IntPtr lpCookie)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+ThemingScope.DeactivateActCtx' has not been implemented!");
    //    }

    //    public static System.Boolean GetCurrentActCtx(System.IntPtr* handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+ThemingScope.GetCurrentActCtx' has not been implemented!");
    //    }
    //}
}
