namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Windows_Forms_UnsafeNativeMethodsImpl
    //{

    //    public static System.IntPtr GetCapture()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetCapture' has not been implemented!");
    //    }

    //    public static System.IntPtr SetClassLongPtr32(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 nIndex, System.IntPtr dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetClassLongPtr32' has not been implemented!");
    //    }

    //    public static System.Object CoCreateInstance(System.Guid* clsid, System.Object punkOuter, System.Int32 context, System.Guid* iid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CoCreateInstance' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IPicture OleCreateIPictureIndirect(System.Object pictdesc, System.Guid* iid, System.Boolean fOwn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreateIPictureIndirect' has not been implemented!");
    //    }

    //    public static System.Boolean InsertMenuItem(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 uItem, System.Boolean fByPosition, System.Windows.Forms.NativeMethods+MENUITEMINFO_T lpmii)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.InsertMenuItem' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateMenu()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateMenu' has not been implemented!");
    //    }

    //    public static System.Void CopyMemory(System.Runtime.InteropServices.HandleRef destData, System.Runtime.InteropServices.HandleRef srcData, System.Int32 size)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemory' has not been implemented!");
    //    }

    //    public static System.IntPtr IntDuplicateHandle(System.Runtime.InteropServices.HandleRef processSource, System.Runtime.InteropServices.HandleRef handleSource, System.Runtime.InteropServices.HandleRef processTarget, System.IntPtr* handleTarget, System.Int32 desiredAccess, System.Boolean inheritHandle, System.Int32 options)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDuplicateHandle' has not been implemented!");
    //    }

    //    public static System.Int32 GetModuleFileName(System.Runtime.InteropServices.HandleRef hModule, System.Text.StringBuilder buffer, System.Int32 length)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetModuleFileName' has not been implemented!");
    //    }

    //    public static System.Boolean TranslateMessage(System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.TranslateMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr DispatchMessageA(System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DispatchMessageA' has not been implemented!");
    //    }

    //    public static System.IntPtr DispatchMessageW(System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DispatchMessageW' has not been implemented!");
    //    }

    //    public static System.Int32 PostThreadMessage(System.Int32 id, System.Int32 msg, System.IntPtr wparam, System.IntPtr lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PostThreadMessage' has not been implemented!");
    //    }

    //    public static System.Int32 CoRegisterMessageFilter(System.Runtime.InteropServices.HandleRef newFilter, System.IntPtr* oldMsgFilter)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CoRegisterMessageFilter' has not been implemented!");
    //    }

    //    public static System.Int32 IntOleInitialize(System.Int32 val)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntOleInitialize' has not been implemented!");
    //    }

    //    public static System.Boolean EnumThreadWindows(System.Int32 dwThreadId, System.Windows.Forms.NativeMethods+EnumThreadWindowsCallback lpfn, System.Runtime.InteropServices.HandleRef lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.EnumThreadWindows' has not been implemented!");
    //    }

    //    public static System.Int32 OleUninitialize()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleUninitialize' has not been implemented!");
    //    }

    //    public static System.Boolean IntCloseHandle(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCloseHandle' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateCompatibleDC(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateCompatibleDC' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Windows.Forms.NativeMethods+BITMAP bm)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.IntPtr GetFocus()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetFocus' has not been implemented!");
    //    }

    //    public static System.Boolean GetCursorPos(System.Windows.Forms.NativeMethods+POINT pt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetCursorPos' has not been implemented!");
    //    }

    //    public static System.Int16 GetKeyState(System.Int32 keyCode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetKeyState' has not been implemented!");
    //    }

    //    public static System.Int32 GetWindowText(System.Runtime.InteropServices.HandleRef hWnd, System.Text.StringBuilder lpString, System.Int32 nMaxCount)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindowText' has not been implemented!");
    //    }

    //    public static System.Boolean SetWindowText(System.Runtime.InteropServices.HandleRef hWnd, System.String text)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowText' has not been implemented!");
    //    }

    //    public static System.IntPtr SetFocus(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetFocus' has not been implemented!");
    //    }

    //    public static System.IntPtr GetParent(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetParent' has not been implemented!");
    //    }

    //    public static System.IntPtr GetAncestor(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetAncestor' has not been implemented!");
    //    }

    //    public static System.Boolean IsChild(System.Runtime.InteropServices.HandleRef hWndParent, System.Runtime.InteropServices.HandleRef hwnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IsChild' has not been implemented!");
    //    }

    //    public static System.Boolean IsZoomed(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IsZoomed' has not been implemented!");
    //    }

    //    public static System.Int32 MapWindowPoints(System.Runtime.InteropServices.HandleRef hWndFrom, System.Runtime.InteropServices.HandleRef hWndTo, System.Windows.Forms.NativeMethods+RECT* rect, System.Int32 cPoints)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.MapWindowPoints' has not been implemented!");
    //    }

    //    public static System.Int32 MapWindowPoints(System.Runtime.InteropServices.HandleRef hWndFrom, System.Runtime.InteropServices.HandleRef hWndTo, System.Windows.Forms.NativeMethods+POINT pt, System.Int32 cPoints)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.MapWindowPoints' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32* wParam, System.Int32* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.String lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.IntPtr wParam, System.String lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TOOLINFO_TOOLTIP lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TV_ITEM* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TV_INSERTSTRUCT* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+CHARFORMATA lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+CHARRANGE lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+EDITSTREAM lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Int32 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.Int32 wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SetParent(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hWndParent)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetParent' has not been implemented!");
    //    }

    //    public static System.Boolean GetWindowRect(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+RECT* rect)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindowRect' has not been implemented!");
    //    }

    //    public static System.IntPtr GetWindow(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 uCmd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr GetModuleHandle(System.String modName)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetModuleHandle' has not been implemented!");
    //    }

    //    public static System.IntPtr CallWindowProc(System.IntPtr wndProc, System.IntPtr hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CallWindowProc' has not been implemented!");
    //    }

    //    public static System.IntPtr GetProcAddress(System.Runtime.InteropServices.HandleRef hModule, System.String lpProcName)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetProcAddress' has not been implemented!");
    //    }

    //    public static System.Boolean GetClassInfo(System.Runtime.InteropServices.HandleRef hInst, System.String lpszClass, System.Windows.Forms.NativeMethods+WNDCLASS_I wc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetClassInfo' has not been implemented!");
    //    }

    //    public static System.Int32 GetSystemMetrics(System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetSystemMetrics' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Int32* value, System.Int32 ignore)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Boolean* value, System.Int32 ignore)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Windows.Forms.NativeMethods+HIGHCONTRAST_I* rc, System.Int32 nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.IntPtr GetForegroundWindow()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetForegroundWindow' has not been implemented!");
    //    }

    //    public static System.Int32 RegisterDragDrop(System.Runtime.InteropServices.HandleRef hwnd, System.Windows.Forms.UnsafeNativeMethods+IOleDropTarget target)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.RegisterDragDrop' has not been implemented!");
    //    }

    //    public static System.Boolean PeekMessage(System.Windows.Forms.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msgMin, System.Int32 msgMax, System.Int32 remove)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PeekMessage' has not been implemented!");
    //    }

    //    public static System.Boolean PostMessage(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msg, System.IntPtr wparam, System.IntPtr lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PostMessage' has not been implemented!");
    //    }

    //    public static System.Void NotifyWinEvent(System.Int32 winEvent, System.Runtime.InteropServices.HandleRef hwnd, System.Int32 objType, System.Int32 objID)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.NotifyWinEvent' has not been implemented!");
    //    }

    //    public static System.IntPtr IntBeginPaint(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+PAINTSTRUCT* lpPaint)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntBeginPaint' has not been implemented!");
    //    }

    //    public static System.Boolean IntEndPaint(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+PAINTSTRUCT* lpPaint)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntEndPaint' has not been implemented!");
    //    }

    //    public static System.IntPtr IntGetDC(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntGetDC' has not been implemented!");
    //    }

    //    public static System.IntPtr IntGetWindowDC(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntGetWindowDC' has not been implemented!");
    //    }

    //    public static System.Int32 IntReleaseDC(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntReleaseDC' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateDC(System.String lpszDriver, System.String lpszDeviceName, System.String lpszOutput, System.Runtime.InteropServices.HandleRef devMode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateDC' has not been implemented!");
    //    }

    //    public static System.IntPtr SendCallbackMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendCallbackMessage' has not been implemented!");
    //    }

    //    public static System.Void DragAcceptFiles(System.Runtime.InteropServices.HandleRef hWnd, System.Boolean fAccept)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DragAcceptFiles' has not been implemented!");
    //    }

    //    public static System.Int32 GetDeviceCaps(System.Runtime.InteropServices.HandleRef hDC, System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetDeviceCaps' has not been implemented!");
    //    }

    //    public static System.Int32 SetScrollInfo(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 fnBar, System.Windows.Forms.NativeMethods+SCROLLINFO si, System.Boolean redraw)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetScrollInfo' has not been implemented!");
    //    }

    //    public static System.IntPtr LoadLibrary(System.String libname)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.LoadLibrary' has not been implemented!");
    //    }

    //    public static System.IntPtr GetWindowLong32(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindowLong32' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr32(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Runtime.InteropServices.HandleRef dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowLongPtr32' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr32(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Windows.Forms.NativeMethods+WndProc wndproc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowLongPtr32' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreatePopupMenu()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreatePopupMenu' has not been implemented!");
    //    }

    //    public static System.IntPtr GetSystemMenu(System.Runtime.InteropServices.HandleRef hWnd, System.Boolean bRevert)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetSystemMenu' has not been implemented!");
    //    }

    //    public static System.Boolean SetMenu(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hMenu)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetMenu' has not been implemented!");
    //    }

    //    public static System.Int32 GetWindowPlacement(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+WINDOWPLACEMENT* placement)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindowPlacement' has not been implemented!");
    //    }

    //    public static System.Void GetStartupInfo(System.Windows.Forms.NativeMethods+STARTUPINFO_I startupinfo_i)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetStartupInfo' has not been implemented!");
    //    }

    //    public static System.Boolean EnableMenuItem(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 UIDEnabledItem, System.Int32 uEnable)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.EnableMenuItem' has not been implemented!");
    //    }

    //    public static System.IntPtr SetCursor(System.Runtime.InteropServices.HandleRef hcursor)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetCursor' has not been implemented!");
    //    }

    //    public static System.Boolean IntDestroyCursor(System.Runtime.InteropServices.HandleRef hCurs)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDestroyCursor' has not been implemented!");
    //    }

    //    public static System.Boolean IsWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IsWindow' has not been implemented!");
    //    }

    //    public static System.Boolean IntDeleteDC(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDeleteDC' has not been implemented!");
    //    }

    //    public static System.Boolean GetMessageA(System.Windows.Forms.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hWnd, System.Int32 uMsgFilterMin, System.Int32 uMsgFilterMax)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMessageA' has not been implemented!");
    //    }

    //    public static System.Boolean GetMessageW(System.Windows.Forms.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hWnd, System.Int32 uMsgFilterMin, System.Int32 uMsgFilterMax)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMessageW' has not been implemented!");
    //    }

    //    public static System.IntPtr PostMessage(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msg, System.Int32 wparam, System.Int32 lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PostMessage' has not been implemented!");
    //    }

    //    public static System.Boolean GetClientRect(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+RECT* rect)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetClientRect' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateWindowEx(System.Int32 dwExStyle, System.String lpszClassName, System.String lpszWindowName, System.Int32 style, System.Int32 x, System.Int32 y, System.Int32 width, System.Int32 height, System.Runtime.InteropServices.HandleRef hWndParent, System.Runtime.InteropServices.HandleRef hMenu, System.Runtime.InteropServices.HandleRef hInst, System.Object pvParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateWindowEx' has not been implemented!");
    //    }

    //    public static System.Boolean IntDestroyWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDestroyWindow' has not been implemented!");
    //    }

    //    public static System.Boolean UnregisterClass(System.String className, System.Runtime.InteropServices.HandleRef hInstance)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.UnregisterClass' has not been implemented!");
    //    }

    //    public static System.IntPtr GetStockObject(System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetStockObject' has not been implemented!");
    //    }

    //    public static System.Int16 RegisterClass(System.Windows.Forms.NativeMethods+WNDCLASS_D wc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.RegisterClass' has not been implemented!");
    //    }

    //    public static System.Void WaitMessage()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.WaitMessage' has not been implemented!");
    //    }

    //    public static System.UInt32 SHLoadIndirectString(System.String pszSource, System.Text.StringBuilder pszOutBuf, System.UInt32 cchOutBuf, System.IntPtr ppvReserved)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SHLoadIndirectString' has not been implemented!");
    //    }

    //    public static System.Int32 ReadClassStg(System.Runtime.InteropServices.HandleRef pStg, System.Guid* pclsid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ReadClassStg' has not been implemented!");
    //    }

    //    public static System.Void CoTaskMemFree(System.IntPtr pv)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CoTaskMemFree' has not been implemented!");
    //    }

    //    public static System.Int32 GetClassName(System.Runtime.InteropServices.HandleRef hwnd, System.Text.StringBuilder lpClassName, System.Int32 nMaxCount)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetClassName' has not been implemented!");
    //    }

    //    public static System.IntPtr SetClassLongPtr64(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 nIndex, System.IntPtr dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetClassLongPtr64' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IClassFactory2 CoGetClassObject(System.Guid* clsid, System.Int32 dwContext, System.Int32 serverInfo, System.Guid* refiid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CoGetClassObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetLocaleInfo(System.Int32 Locale, System.Int32 LCType, System.Text.StringBuilder lpLCData, System.Int32 cchData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetLocaleInfo' has not been implemented!");
    //    }

    //    public static System.Int32 WriteClassStm(System.Windows.Forms.UnsafeNativeMethods+IStream pStream, System.Guid* clsid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.WriteClassStm' has not been implemented!");
    //    }

    //    public static System.Int32 ReadClassStg(System.Windows.Forms.UnsafeNativeMethods+IStorage pStorage, System.Guid* clsid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ReadClassStg' has not been implemented!");
    //    }

    //    public static System.Int32 ReadClassStm(System.Windows.Forms.UnsafeNativeMethods+IStream pStream, System.Guid* clsid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ReadClassStm' has not been implemented!");
    //    }

    //    public static System.Int32 OleLoadFromStream(System.Windows.Forms.UnsafeNativeMethods+IStream pStorage, System.Guid* iid, System.Windows.Forms.UnsafeNativeMethods+IOleObject* pObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleLoadFromStream' has not been implemented!");
    //    }

    //    public static System.Int32 OleSaveToStream(System.Windows.Forms.UnsafeNativeMethods+IPersistStream pPersistStream, System.Windows.Forms.UnsafeNativeMethods+IStream pStream)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleSaveToStream' has not been implemented!");
    //    }

    //    public static System.Int32 CoGetMalloc(System.Int32 dwReserved, System.Windows.Forms.UnsafeNativeMethods+IMalloc* pMalloc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CoGetMalloc' has not been implemented!");
    //    }

    //    public static System.Boolean PageSetupDlg(System.Windows.Forms.NativeMethods+PAGESETUPDLG lppsd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PageSetupDlg' has not been implemented!");
    //    }

    //    public static System.Boolean PrintDlg_32(System.Windows.Forms.NativeMethods+PRINTDLG_32 lppd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PrintDlg_32' has not been implemented!");
    //    }

    //    public static System.Boolean PrintDlg_64(System.Windows.Forms.NativeMethods+PRINTDLG_64 lppd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PrintDlg_64' has not been implemented!");
    //    }

    //    public static System.Int32 PrintDlgEx(System.Windows.Forms.NativeMethods+PRINTDLGEX lppdex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PrintDlgEx' has not been implemented!");
    //    }

    //    public static System.Int32 OleGetClipboard(System.Runtime.InteropServices.ComTypes.IDataObject* data)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleGetClipboard' has not been implemented!");
    //    }

    //    public static System.Int32 OleSetClipboard(System.Runtime.InteropServices.ComTypes.IDataObject pDataObj)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleSetClipboard' has not been implemented!");
    //    }

    //    public static System.Int32 OleFlushClipboard()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleFlushClipboard' has not been implemented!");
    //    }

    //    public static System.Void OleCreatePropertyFrameIndirect(System.Windows.Forms.NativeMethods+OCPFIPARAMS p)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreatePropertyFrameIndirect' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IFont OleCreateIFontIndirect(System.Windows.Forms.NativeMethods+FONTDESC fd, System.Guid* iid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreateIFontIndirect' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IPictureDisp OleCreateIPictureDispIndirect(System.Object pictdesc, System.Guid* iid, System.Boolean fOwn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreateIPictureDispIndirect' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IPicture OleCreatePictureIndirect(System.Windows.Forms.NativeMethods+PICTDESC pictdesc, System.Guid* refiid, System.Boolean fOwn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreatePictureIndirect' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IFont OleCreateFontIndirect(System.Windows.Forms.NativeMethods+tagFONTDESC fontdesc, System.Guid* refiid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.OleCreateFontIndirect' has not been implemented!");
    //    }

    //    public static System.Int32 VarFormat(System.Object* pvarIn, System.Runtime.InteropServices.HandleRef pstrFormat, System.Int32 iFirstDay, System.Int32 iFirstWeek, System.UInt32 dwFlags, System.IntPtr* pbstr)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.VarFormat' has not been implemented!");
    //    }

    //    public static System.Int32 DragQueryFile(System.Runtime.InteropServices.HandleRef hDrop, System.Int32 iFile, System.Text.StringBuilder lpszFile, System.Int32 cch)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DragQueryFile' has not been implemented!");
    //    }

    //    public static System.Boolean EnumChildWindows(System.Runtime.InteropServices.HandleRef hwndParent, System.Windows.Forms.NativeMethods+EnumChildrenCallback lpEnumFunc, System.Runtime.InteropServices.HandleRef lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.EnumChildWindows' has not been implemented!");
    //    }

    //    public static System.IntPtr ShellExecute(System.Runtime.InteropServices.HandleRef hwnd, System.String lpOperation, System.String lpFile, System.String lpParameters, System.String lpDirectory, System.Int32 nShowCmd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ShellExecute' has not been implemented!");
    //    }

    //    public static System.IntPtr ShellExecute_NoBFM(System.Runtime.InteropServices.HandleRef hwnd, System.String lpOperation, System.String lpFile, System.String lpParameters, System.String lpDirectory, System.Int32 nShowCmd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ShellExecute_NoBFM' has not been implemented!");
    //    }

    //    public static System.Int32 SetScrollPos(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nBar, System.Int32 nPos, System.Boolean bRedraw)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetScrollPos' has not been implemented!");
    //    }

    //    public static System.Boolean EnableScrollBar(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nBar, System.Int32 value)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.EnableScrollBar' has not been implemented!");
    //    }

    //    public static System.Int32 Shell_NotifyIcon(System.Int32 message, System.Windows.Forms.NativeMethods+NOTIFYICONDATA pnid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.Shell_NotifyIcon' has not been implemented!");
    //    }

    //    public static System.IntPtr GetMenu(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMenu' has not been implemented!");
    //    }

    //    public static System.Boolean GetMenuItemInfo(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 uItem, System.Boolean fByPosition, System.Windows.Forms.NativeMethods+MENUITEMINFO_T lpmii)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMenuItemInfo' has not been implemented!");
    //    }

    //    public static System.Boolean GetMenuItemInfo(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 uItem, System.Boolean fByPosition, System.Windows.Forms.NativeMethods+MENUITEMINFO_T_RW lpmii)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMenuItemInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SetMenuItemInfo(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 uItem, System.Boolean fByPosition, System.Windows.Forms.NativeMethods+MENUITEMINFO_T lpmii)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetMenuItemInfo' has not been implemented!");
    //    }

    //    public static System.Boolean GetOpenFileName(System.Windows.Forms.NativeMethods+OPENFILENAME_I ofn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetOpenFileName' has not been implemented!");
    //    }

    //    public static System.Boolean EndDialog(System.Runtime.InteropServices.HandleRef hWnd, System.IntPtr result)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.EndDialog' has not been implemented!");
    //    }

    //    public static System.Int32 MultiByteToWideChar(System.Int32 CodePage, System.Int32 dwFlags, System.Byte[] lpMultiByteStr, System.Int32 cchMultiByte, System.Char[] lpWideCharStr, System.Int32 cchWideChar)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.MultiByteToWideChar' has not been implemented!");
    //    }

    //    public static System.Int32 WideCharToMultiByte(System.Int32 codePage, System.Int32 flags, System.String wideStr, System.Int32 chars, System.Byte[] pOutBytes, System.Int32 bufferBytes, System.IntPtr defaultChar, System.IntPtr pDefaultUsed)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.WideCharToMultiByte' has not been implemented!");
    //    }

    //    public static System.Void CopyMemory(System.IntPtr pdst, System.Byte[] psrc, System.Int32 cb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemory' has not been implemented!");
    //    }

    //    public static System.Void CopyMemoryW(System.IntPtr pdst, System.String psrc, System.Int32 cb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemoryW' has not been implemented!");
    //    }

    //    public static System.Void CopyMemoryW(System.IntPtr pdst, System.Char[] psrc, System.Int32 cb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemoryW' has not been implemented!");
    //    }

    //    public static System.Void CopyMemoryA(System.IntPtr pdst, System.String psrc, System.Int32 cb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemoryA' has not been implemented!");
    //    }

    //    public static System.Void CopyMemoryA(System.IntPtr pdst, System.Char[] psrc, System.Int32 cb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CopyMemoryA' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IStorage StgOpenStorageOnILockBytes(System.Windows.Forms.UnsafeNativeMethods+ILockBytes iLockBytes, System.Windows.Forms.UnsafeNativeMethods+IStorage pStgPriority, System.Int32 grfMode, System.Int32 sndExcluded, System.Int32 reserved)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.StgOpenStorageOnILockBytes' has not been implemented!");
    //    }

    //    public static System.IntPtr GetHGlobalFromILockBytes(System.Windows.Forms.UnsafeNativeMethods+ILockBytes pLkbyt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetHGlobalFromILockBytes' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowsHookEx(System.Int32 hookid, System.Windows.Forms.NativeMethods+HookProc pfnhook, System.Runtime.InteropServices.HandleRef hinst, System.Int32 threadid)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowsHookEx' has not been implemented!");
    //    }

    //    public static System.Int32 GetKeyboardState(System.Byte[] keystate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetKeyboardState' has not been implemented!");
    //    }

    //    public static System.Void Keybd_event(System.Byte vk, System.Byte scan, System.Int32 flags, System.Int32 extrainfo)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.Keybd_event' has not been implemented!");
    //    }

    //    public static System.Int32 SetKeyboardState(System.Byte[] keystate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetKeyboardState' has not been implemented!");
    //    }

    //    public static System.Boolean UnhookWindowsHookEx(System.Runtime.InteropServices.HandleRef hhook)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.UnhookWindowsHookEx' has not been implemented!");
    //    }

    //    public static System.Int16 GetAsyncKeyState(System.Int32 vkey)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetAsyncKeyState' has not been implemented!");
    //    }

    //    public static System.IntPtr CallNextHookEx(System.Runtime.InteropServices.HandleRef hhook, System.Int32 code, System.IntPtr wparam, System.IntPtr lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CallNextHookEx' has not been implemented!");
    //    }

    //    public static System.Int32 ScreenToClient(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+POINT pt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ScreenToClient' has not been implemented!");
    //    }

    //    public static System.Boolean IsDialogMessage(System.Runtime.InteropServices.HandleRef hWndDlg, System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IsDialogMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr DispatchMessage(System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DispatchMessage' has not been implemented!");
    //    }

    //    public static System.Boolean GetExitCodeThread(System.IntPtr hThread, System.UInt32* lpExitCode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetExitCodeThread' has not been implemented!");
    //    }

    //    public static System.IntPtr SendDlgItemMessage(System.Runtime.InteropServices.HandleRef hDlg, System.Int32 nIDDlgItem, System.Int32 Msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendDlgItemMessage' has not been implemented!");
    //    }

    //    public static System.Boolean GetSaveFileName(System.Windows.Forms.NativeMethods+OPENFILENAME_I ofn)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetSaveFileName' has not been implemented!");
    //    }

    //    public static System.IntPtr _ChildWindowFromPointEx(System.Runtime.InteropServices.HandleRef hwndParent, System.Windows.Forms.UnsafeNativeMethods+POINTSTRUCT pt, System.Int32 uFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods._ChildWindowFromPointEx' has not been implemented!");
    //    }

    //    public static System.Boolean BlockInput(System.Boolean fBlockIt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.BlockInput' has not been implemented!");
    //    }

    //    public static System.UInt32 SendInput(System.UInt32 nInputs, System.Windows.Forms.NativeMethods+INPUT[] pInputs, System.Int32 cbSize)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendInput' has not been implemented!");
    //    }

    //    public static System.IntPtr IntMapViewOfFile(System.Runtime.InteropServices.HandleRef hFileMapping, System.Int32 dwDesiredAccess, System.Int32 dwFileOffsetHigh, System.Int32 dwFileOffsetLow, System.Int32 dwNumberOfBytesToMap)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntMapViewOfFile' has not been implemented!");
    //    }

    //    public static System.Boolean IntUnmapViewOfFile(System.Runtime.InteropServices.HandleRef pvBaseAddress)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntUnmapViewOfFile' has not been implemented!");
    //    }

    //    public static System.IntPtr IntGetDCEx(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hrgnClip, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntGetDCEx' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Windows.Forms.NativeMethods+LOGPEN lp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Windows.Forms.NativeMethods+LOGBRUSH lb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Windows.Forms.NativeMethods+LOGFONT lf)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Int32* nEntries)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetObject(System.Runtime.InteropServices.HandleRef hObject, System.Int32 nSize, System.Int32[] nEntries)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetObjectType(System.Runtime.InteropServices.HandleRef hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetObjectType' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateAcceleratorTable(System.Runtime.InteropServices.HandleRef pentries, System.Int32 cCount)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateAcceleratorTable' has not been implemented!");
    //    }

    //    public static System.Boolean IntDestroyAcceleratorTable(System.Runtime.InteropServices.HandleRef hAccel)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDestroyAcceleratorTable' has not been implemented!");
    //    }

    //    public static System.Int16 VkKeyScan(System.Char key)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.VkKeyScan' has not been implemented!");
    //    }

    //    public static System.IntPtr SetCapture(System.Runtime.InteropServices.HandleRef hwnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetCapture' has not been implemented!");
    //    }

    //    public static System.UInt32 GetShortPathName(System.String lpszLongPath, System.Text.StringBuilder lpszShortPath, System.UInt32 cchBuffer)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetShortPathName' has not been implemented!");
    //    }

    //    public static System.Int32 IntSetWindowRgn(System.Runtime.InteropServices.HandleRef hwnd, System.Runtime.InteropServices.HandleRef hrgn, System.Boolean fRedraw)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntSetWindowRgn' has not been implemented!");
    //    }

    //    public static System.Void GetTempFileName(System.String tempDirName, System.String prefixName, System.Int32 unique, System.Text.StringBuilder sb)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetTempFileName' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalAlloc(System.Int32 uFlags, System.Int32 dwBytes)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalAlloc' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalReAlloc(System.Runtime.InteropServices.HandleRef handle, System.Int32 bytes, System.Int32 flags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalReAlloc' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalLock(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalLock' has not been implemented!");
    //    }

    //    public static System.Boolean GlobalUnlock(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalUnlock' has not been implemented!");
    //    }

    //    public static System.IntPtr GlobalFree(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalFree' has not been implemented!");
    //    }

    //    public static System.Int32 GlobalSize(System.Runtime.InteropServices.HandleRef handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalSize' has not been implemented!");
    //    }

    //    public static System.Boolean ImmSetConversionStatus(System.Runtime.InteropServices.HandleRef hIMC, System.Int32 conversion, System.Int32 sentence)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmSetConversionStatus' has not been implemented!");
    //    }

    //    public static System.Boolean ImmGetConversionStatus(System.Runtime.InteropServices.HandleRef hIMC, System.Int32* conversion, System.Int32* sentence)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmGetConversionStatus' has not been implemented!");
    //    }

    //    public static System.IntPtr ImmGetContext(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmGetContext' has not been implemented!");
    //    }

    //    public static System.Boolean ImmReleaseContext(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hIMC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmReleaseContext' has not been implemented!");
    //    }

    //    public static System.IntPtr ImmAssociateContext(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef hIMC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmAssociateContext' has not been implemented!");
    //    }

    //    public static System.Boolean ImmDestroyContext(System.Runtime.InteropServices.HandleRef hIMC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmDestroyContext' has not been implemented!");
    //    }

    //    public static System.IntPtr ImmCreateContext()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmCreateContext' has not been implemented!");
    //    }

    //    public static System.Boolean ImmSetOpenStatus(System.Runtime.InteropServices.HandleRef hIMC, System.Boolean open)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmSetOpenStatus' has not been implemented!");
    //    }

    //    public static System.Boolean ImmGetOpenStatus(System.Runtime.InteropServices.HandleRef hIMC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmGetOpenStatus' has not been implemented!");
    //    }

    //    public static System.Boolean ImmNotifyIME(System.Runtime.InteropServices.HandleRef hIMC, System.Int32 dwAction, System.Int32 dwIndex, System.Int32 dwValue)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ImmNotifyIME' has not been implemented!");
    //    }

    //    public static System.IntPtr FindWindow(System.String className, System.String windowName)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.FindWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Boolean wParam, System.Int32 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Int32[] lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32[] wParam, System.Int32[] lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Text.StringBuilder lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TOOLINFO_T lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TBBUTTON* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TBBUTTONINFO* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TV_HITTESTINFO lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVBKIMAGE lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Int32 SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVHITTESTINFO* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TCITEM_T lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+HDLAYOUT* hdlayout)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Runtime.InteropServices.HandleRef wParam, System.Int32 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Runtime.InteropServices.HandleRef lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+PARAFORMAT lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+CHARFORMAT2A lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+CHARFORMATW lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Int32 SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Object* editOle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+FINDTEXT lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+TEXTRANGE lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+POINT lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Windows.Forms.NativeMethods+POINT wParam, System.Int32 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+REPASTESPECIAL lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+EDITSTREAM64 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Windows.Forms.NativeMethods+GETTEXTLENGTHEX wParam, System.Int32 lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+SIZE lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVFINDINFO* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVHITTESTINFO lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVCOLUMN_T lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVITEM* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVCOLUMN lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVGROUP lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Windows.Forms.NativeMethods+POINT wParam, System.Windows.Forms.NativeMethods+LVINSERTMARK lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Boolean SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVINSERTMARK lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Boolean SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LVTILEVIEWINFO lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+MCHITTESTINFO lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+SYSTEMTIME lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+SYSTEMTIMEARRAY lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+LOGFONT lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+MSG lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.IntPtr wParam, System.Windows.Forms.NativeMethods+RECT* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.Int16* wParam, System.Int16* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.Boolean* wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.Int32 wParam, System.Windows.Forms.NativeMethods+RECT* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.Int32 wParam, System.Drawing.Rectangle* lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 Msg, System.IntPtr wParam, System.Windows.Forms.NativeMethods+ListViewCompareCallback pfnCompare)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessageTimeout(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam, System.Int32 flags, System.Int32 timeout, System.IntPtr* pdwResult)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SendMessageTimeout' has not been implemented!");
    //    }

    //    public static System.IntPtr GetDlgItem(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIDDlgItem)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetDlgItem' has not been implemented!");
    //    }

    //    public static System.IntPtr DefWindowProc(System.IntPtr hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DefWindowProc' has not been implemented!");
    //    }

    //    public static System.IntPtr DefMDIChildProc(System.IntPtr hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DefMDIChildProc' has not been implemented!");
    //    }

    //    public static System.Int16 GlobalDeleteAtom(System.Int16 atom)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalDeleteAtom' has not been implemented!");
    //    }

    //    public static System.Boolean GetClassInfo(System.Runtime.InteropServices.HandleRef hInst, System.String lpszClass, System.IntPtr h)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetClassInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Windows.Forms.NativeMethods+RECT* rc, System.Int32 nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Windows.Forms.NativeMethods+NONCLIENTMETRICS metrics, System.Int32 nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Windows.Forms.NativeMethods+LOGFONT font, System.Int32 nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.Boolean[] flag, System.Boolean nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean GetComputerName(System.Text.StringBuilder lpBuffer, System.Int32[] nSize)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetComputerName' has not been implemented!");
    //    }

    //    public static System.Boolean GetUserName(System.Text.StringBuilder lpBuffer, System.Int32[] nSize)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetUserName' has not been implemented!");
    //    }

    //    public static System.IntPtr GetProcessWindowStation()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetProcessWindowStation' has not been implemented!");
    //    }

    //    public static System.Boolean GetUserObjectInformation(System.Runtime.InteropServices.HandleRef hObj, System.Int32 nIndex, System.Windows.Forms.NativeMethods+USEROBJECTFLAGS pvBuffer, System.Int32 nLength, System.Int32* lpnLengthNeeded)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetUserObjectInformation' has not been implemented!");
    //    }

    //    public static System.Int32 ClientToScreen(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+POINT pt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ClientToScreen' has not been implemented!");
    //    }

    //    public static System.Int32 MsgWaitForMultipleObjectsEx(System.Int32 nCount, System.IntPtr pHandles, System.Int32 dwMilliseconds, System.Int32 dwWakeMask, System.Int32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.MsgWaitForMultipleObjectsEx' has not been implemented!");
    //    }

    //    public static System.IntPtr GetDesktopWindow()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetDesktopWindow' has not been implemented!");
    //    }

    //    public static System.Int32 RevokeDragDrop(System.Runtime.InteropServices.HandleRef hwnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.RevokeDragDrop' has not been implemented!");
    //    }

    //    public static System.Boolean PeekMessageW(System.Windows.Forms.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msgMin, System.Int32 msgMax, System.Int32 remove)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PeekMessageW' has not been implemented!");
    //    }

    //    public static System.Boolean PeekMessageA(System.Windows.Forms.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msgMin, System.Int32 msgMax, System.Int32 remove)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PeekMessageA' has not been implemented!");
    //    }

    //    public static System.Int16 GlobalAddAtom(System.String atomName)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GlobalAddAtom' has not been implemented!");
    //    }

    //    public static System.IntPtr LresultFromObject(System.Guid* refiid, System.IntPtr wParam, System.Runtime.InteropServices.HandleRef pAcc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.LresultFromObject' has not been implemented!");
    //    }

    //    public static System.Int32 CreateStdAccessibleObject(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 objID, System.Guid* refiid, System.Object* pAcc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CreateStdAccessibleObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetMenuItemID(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 nPos)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMenuItemID' has not been implemented!");
    //    }

    //    public static System.IntPtr GetSubMenu(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 index)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetSubMenu' has not been implemented!");
    //    }

    //    public static System.Int32 GetMenuItemCount(System.Runtime.InteropServices.HandleRef hMenu)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetMenuItemCount' has not been implemented!");
    //    }

    //    public static System.Void GetErrorInfo(System.Int32 reserved, System.Windows.Forms.UnsafeNativeMethods+IErrorInfo* errorInfo)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetErrorInfo' has not been implemented!");
    //    }

    //    public static System.Boolean SystemParametersInfo(System.Int32 nAction, System.Int32 nParam, System.IntPtr[] rc, System.Int32 nUpdate)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SystemParametersInfo' has not been implemented!");
    //    }

    //    public static System.Boolean GetScrollInfo(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 fnBar, System.Windows.Forms.NativeMethods+SCROLLINFO si)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetScrollInfo' has not been implemented!");
    //    }

    //    public static System.IntPtr GetActiveWindow()
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetActiveWindow' has not been implemented!");
    //    }

    //    public static System.Boolean FreeLibrary(System.Runtime.InteropServices.HandleRef hModule)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.FreeLibrary' has not been implemented!");
    //    }

    //    public static System.IntPtr GetWindowLongPtr64(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetWindowLongPtr64' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr64(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Runtime.InteropServices.HandleRef dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowLongPtr64' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr64(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Windows.Forms.NativeMethods+WndProc wndproc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowLongPtr64' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+ILockBytes CreateILockBytesOnHGlobal(System.Runtime.InteropServices.HandleRef hGlobal, System.Boolean fDeleteOnRelease)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CreateILockBytesOnHGlobal' has not been implemented!");
    //    }

    //    public static System.Windows.Forms.UnsafeNativeMethods+IStorage StgCreateDocfileOnILockBytes(System.Windows.Forms.UnsafeNativeMethods+ILockBytes iLockBytes, System.Int32 grfMode, System.Int32 reserved)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.StgCreateDocfileOnILockBytes' has not been implemented!");
    //    }

    //    public static System.Boolean RemoveMenu(System.Runtime.InteropServices.HandleRef hMenu, System.Int32 uPosition, System.Int32 uFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.RemoveMenu' has not been implemented!");
    //    }

    //    public static System.Boolean IntDestroyMenu(System.Runtime.InteropServices.HandleRef hMenu)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntDestroyMenu' has not been implemented!");
    //    }

    //    public static System.Boolean SetForegroundWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetForegroundWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr DefFrameProc(System.IntPtr hWnd, System.IntPtr hWndClient, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.DefFrameProc' has not been implemented!");
    //    }

    //    public static System.Boolean TranslateMDISysAccel(System.IntPtr hWndClient, System.Windows.Forms.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.TranslateMDISysAccel' has not been implemented!");
    //    }

    //    public static System.Boolean SetLayeredWindowAttributes(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 crKey, System.Byte bAlpha, System.Int32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetLayeredWindowAttributes' has not been implemented!");
    //    }

    //    public static System.Boolean SetMenuDefaultItem(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 nIndex, System.Boolean pos)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetMenuDefaultItem' has not been implemented!");
    //    }

    //    public static System.IntPtr SetActiveWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetActiveWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr IntCreateIC(System.String lpszDriverName, System.String lpszDeviceName, System.String lpszOutput, System.Runtime.InteropServices.HandleRef lpInitData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.IntCreateIC' has not been implemented!");
    //    }

    //    public static System.Boolean ClipCursor(System.Windows.Forms.NativeMethods+RECT* rcClip)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ClipCursor' has not been implemented!");
    //    }

    //    public static System.Boolean ClipCursor(System.Windows.Forms.NativeMethods+COMRECT rcClip)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ClipCursor' has not been implemented!");
    //    }

    //    public static System.Boolean SetCursorPos(System.Int32 x, System.Int32 y)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetCursorPos' has not been implemented!");
    //    }

    //    public static System.Int32 ShowCursor(System.Boolean bShow)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.ShowCursor' has not been implemented!");
    //    }

    //    public static System.IntPtr PostMessage(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msg, System.Int32 wparam, System.IntPtr lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PostMessage' has not been implemented!");
    //    }

    //    public static System.Boolean GetClientRect(System.Runtime.InteropServices.HandleRef hWnd, System.IntPtr rect)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetClientRect' has not been implemented!");
    //    }

    //    public static System.IntPtr _WindowFromPoint(System.Windows.Forms.UnsafeNativeMethods+POINTSTRUCT pt)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods._WindowFromPoint' has not been implemented!");
    //    }

    //    public static System.IntPtr WindowFromDC(System.Runtime.InteropServices.HandleRef hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.WindowFromDC' has not been implemented!");
    //    }

    //    public static System.Void PostQuitMessage(System.Int32 nExitCode)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.PostQuitMessage' has not been implemented!");
    //    }

    //    public static System.Boolean SetWindowPlacement(System.Runtime.InteropServices.HandleRef hWnd, System.Windows.Forms.NativeMethods+WINDOWPLACEMENT* placement)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetWindowPlacement' has not been implemented!");
    //    }

    //    public static System.Boolean GetSystemPowerStatus(System.Windows.Forms.NativeMethods+SYSTEM_POWER_STATUS* systemPowerStatus)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetSystemPowerStatus' has not been implemented!");
    //    }

    //    public static System.Boolean SetSuspendState(System.Boolean hiberate, System.Boolean forceCritical, System.Boolean disableWakeEvent)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.SetSuspendState' has not been implemented!");
    //    }

    //    public static System.Int32 GetRegionData(System.Runtime.InteropServices.HandleRef hRgn, System.Int32 size, System.IntPtr lpRgnData)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.GetRegionData' has not been implemented!");
    //    }

    //    public static System.Void CorLaunchApplication(System.UInt32 hostType, System.String applicationFullName, System.Int32 manifestPathsCount, System.String[] manifestPaths, System.Int32 activationDataCount, System.String[] activationData, System.Windows.Forms.UnsafeNativeMethods+PROCESS_INFORMATION processInformation)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods.CorLaunchApplication' has not been implemented!");
    //    }
    //}
}
