namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.Shell32), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Windows_Forms_UnsafeNativeMethods+Shell32Impl
    //{

    //    public static System.Int32 SHGetSpecialFolderLocation(System.IntPtr hwnd, System.Int32 csidl, System.IntPtr* ppidl)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHGetSpecialFolderLocation' has not been implemented!");
    //    }

    //    public static System.Boolean SHGetPathFromIDList(System.IntPtr pidl, System.IntPtr pszPath)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHGetPathFromIDList' has not been implemented!");
    //    }

    //    public static System.IntPtr SHBrowseForFolder(System.Windows.Forms.UnsafeNativeMethods+BROWSEINFO lpbi)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHBrowseForFolder' has not been implemented!");
    //    }

    //    public static System.Int32 SHGetMalloc(System.Windows.Forms.UnsafeNativeMethods+IMalloc[] ppMalloc)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHGetMalloc' has not been implemented!");
    //    }

    //    public static System.Int32 SHGetFolderPathExPrivate(System.Guid* rfid, System.UInt32 dwFlags, System.IntPtr hToken, System.Text.StringBuilder pszPath, System.UInt32 cchPath)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHGetFolderPathExPrivate' has not been implemented!");
    //    }

    //    public static System.Int32 SHCreateShellItem(System.IntPtr pidlParent, System.IntPtr psfParent, System.IntPtr pidl, System.Windows.Forms.FileDialogNative+IShellItem* ppsi)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHCreateShellItem' has not been implemented!");
    //    }

    //    public static System.Int32 SHILCreateFromPath(System.String pszPath, System.IntPtr* ppIdl, System.UInt32* rgflnOut)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+Shell32.SHILCreateFromPath' has not been implemented!");
    //    }
    //}
}
