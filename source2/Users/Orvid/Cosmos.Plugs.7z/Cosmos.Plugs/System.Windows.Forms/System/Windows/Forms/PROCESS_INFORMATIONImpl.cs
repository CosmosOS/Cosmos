namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.PROCESS_INFORMATION), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Windows_Forms_UnsafeNativeMethods+PROCESS_INFORMATIONImpl
	{

		public static System.Boolean CloseHandle(System.Runtime.InteropServices.HandleRef handle)
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.UnsafeNativeMethods+PROCESS_INFORMATION.CloseHandle' has not been implemented!");
		}
	}
}
