namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Windows.Forms.Internal.DbgUtil), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Windows_Forms_Internal_DbgUtilImpl
	{

		public static System.Int32 GetUserDefaultLCID()
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.Internal.DbgUtil.GetUserDefaultLCID' has not been implemented!");
		}

		public static System.Int32 FormatMessage(System.Int32 dwFlags, System.Runtime.InteropServices.HandleRef lpSource, System.Int32 dwMessageId, System.Int32 dwLanguageId, System.Text.StringBuilder lpBuffer, System.Int32 nSize, System.Runtime.InteropServices.HandleRef arguments)
		{
			throw new System.NotImplementedException("Method 'System.Windows.Forms.Internal.DbgUtil.FormatMessage' has not been implemented!");
		}
	}
}
