namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.SafeHandles.SafeProcessHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class Microsoft_Win32_SafeHandles_SafeProcessHandleImpl
	{

		public static Microsoft.Win32.SafeHandles.SafeProcessHandle OpenProcess(System.Int32 access, System.Boolean inherit, System.Int32 processId)
		{
			throw new System.NotImplementedException("Method 'Microsoft.Win32.SafeHandles.SafeProcessHandle.OpenProcess' has not been implemented!");
		}
	}
}
