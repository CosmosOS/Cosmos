namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.SafeHandles.SafeUserTokenHandle), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class Microsoft_Win32_SafeHandles_SafeUserTokenHandleImpl
    //{

    //    public static System.Boolean CloseHandle(System.IntPtr handle)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.SafeHandles.SafeUserTokenHandle.CloseHandle' has not been implemented!");
    //    }

    //    public static System.Boolean DuplicateTokenEx(System.Runtime.InteropServices.SafeHandle hToken, System.Int32 access, Microsoft.Win32.NativeMethods+SECURITY_ATTRIBUTES tokenAttributes, System.Int32 impersonationLevel, System.Int32 tokenType, Microsoft.Win32.SafeHandles.SafeUserTokenHandle* hNewToken)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.SafeHandles.SafeUserTokenHandle.DuplicateTokenEx' has not been implemented!");
    //    }
    //}
}
