namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(Microsoft.Win32.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class Microsoft_Win32_UnsafeNativeMethodsImpl
    //{

    //    public static System.IntPtr GetStdHandle(System.Int32 type)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetStdHandle' has not been implemented!");
    //    }

    //    public static System.IntPtr GetProcessWindowStation()
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetProcessWindowStation' has not been implemented!");
    //    }

    //    public static System.Boolean GetUserObjectInformation(System.Runtime.InteropServices.HandleRef hObj, System.Int32 nIndex, Microsoft.Win32.NativeMethods+USEROBJECTFLAGS pvBuffer, System.Int32 nLength, System.Int32* lpnLengthNeeded)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetUserObjectInformation' has not been implemented!");
    //    }

    //    public static System.IntPtr GetModuleHandle(System.String modName)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetModuleHandle' has not been implemented!");
    //    }

    //    public static System.Boolean GetClassInfo(System.Runtime.InteropServices.HandleRef hInst, System.String lpszClass, Microsoft.Win32.NativeMethods+WNDCLASS_I wc)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetClassInfo' has not been implemented!");
    //    }

    //    public static System.Boolean IsWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.IsWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr SetClassLongPtr32(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 nIndex, System.IntPtr dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetClassLongPtr32' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr32(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Runtime.InteropServices.HandleRef dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetWindowLongPtr32' has not been implemented!");
    //    }

    //    public static System.Int16 RegisterClass(Microsoft.Win32.NativeMethods+WNDCLASS wc)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.RegisterClass' has not been implemented!");
    //    }

    //    public static System.IntPtr CreateWindowEx(System.Int32 exStyle, System.String lpszClassName, System.String lpszWindowName, System.Int32 style, System.Int32 x, System.Int32 y, System.Int32 width, System.Int32 height, System.Runtime.InteropServices.HandleRef hWndParent, System.Runtime.InteropServices.HandleRef hMenu, System.Runtime.InteropServices.HandleRef hInst, System.Object pvParam)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.CreateWindowEx' has not been implemented!");
    //    }

    //    public static System.Boolean SetConsoleCtrlHandler(Microsoft.Win32.NativeMethods+ConHndlr handler, System.Int32 add)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetConsoleCtrlHandler' has not been implemented!");
    //    }

    //    public static System.IntPtr DefWindowProc(System.IntPtr hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.DefWindowProc' has not been implemented!");
    //    }

    //    public static System.Boolean DestroyWindow(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.DestroyWindow' has not been implemented!");
    //    }

    //    public static System.IntPtr GetProcAddress(System.Runtime.InteropServices.HandleRef hModule, System.String lpProcName)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetProcAddress' has not been implemented!");
    //    }

    //    public static System.Boolean PostMessage(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msg, System.IntPtr wparam, System.IntPtr lparam)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.PostMessage' has not been implemented!");
    //    }

    //    public static System.Int32 GetFileVersionInfoSize(System.String lptstrFilename, System.Int32* handle)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetFileVersionInfoSize' has not been implemented!");
    //    }

    //    public static System.Boolean GetFileVersionInfo(System.String lptstrFilename, System.Int32 dwHandle, System.Int32 dwLen, System.Runtime.InteropServices.HandleRef lpData)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetFileVersionInfo' has not been implemented!");
    //    }

    //    public static System.Boolean VerQueryValue(System.Runtime.InteropServices.HandleRef pBlock, System.String lpSubBlock, System.IntPtr* lplpBuffer, System.Int32* len)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.VerQueryValue' has not been implemented!");
    //    }

    //    public static System.Int32 VerLanguageName(System.Int32 langID, System.Text.StringBuilder lpBuffer, System.Int32 nSize)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.VerLanguageName' has not been implemented!");
    //    }

    //    public static System.Boolean ReadDirectoryChangesW(Microsoft.Win32.SafeHandles.SafeFileHandle hDirectory, System.Runtime.InteropServices.HandleRef lpBuffer, System.Int32 nBufferLength, System.Int32 bWatchSubtree, System.Int32 dwNotifyFilter, System.Int32* lpBytesReturned, System.Threading.NativeOverlapped* overlappedPointer, System.Runtime.InteropServices.HandleRef lpCompletionRoutine)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReadDirectoryChangesW' has not been implemented!");
    //    }

    //    public static System.Int32 ReleaseDC(System.IntPtr hWnd, System.IntPtr hDC)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReleaseDC' has not been implemented!");
    //    }

    //    public static System.IntPtr GetDC(System.IntPtr hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetDC' has not been implemented!");
    //    }

    //    public static System.IntPtr SelectObject(System.IntPtr hDC, System.IntPtr hObject)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SelectObject' has not been implemented!");
    //    }

    //    public static System.Int32 GetSystemMetrics(System.Int32 nIndex)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetSystemMetrics' has not been implemented!");
    //    }

    //    public static System.IntPtr SetClassLongPtr64(System.Runtime.InteropServices.HandleRef hwnd, System.Int32 nIndex, System.IntPtr dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetClassLongPtr64' has not been implemented!");
    //    }

    //    public static System.IntPtr SetWindowLongPtr64(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 nIndex, System.Runtime.InteropServices.HandleRef dwNewLong)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetWindowLongPtr64' has not been implemented!");
    //    }

    //    public static System.Int16 UnregisterClass(System.String lpClassName, System.Runtime.InteropServices.HandleRef hInstance)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.UnregisterClass' has not been implemented!");
    //    }

    //    public static System.IntPtr SendMessage(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 msg, System.IntPtr wParam, System.IntPtr lParam)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SendMessage' has not been implemented!");
    //    }

    //    public static System.Int32 MsgWaitForMultipleObjectsEx(System.Int32 nCount, System.IntPtr pHandles, System.Int32 dwMilliseconds, System.Int32 dwWakeMask, System.Int32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.MsgWaitForMultipleObjectsEx' has not been implemented!");
    //    }

    //    public static System.Int32 DispatchMessage(Microsoft.Win32.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.DispatchMessage' has not been implemented!");
    //    }

    //    public static System.Boolean PeekMessage(Microsoft.Win32.NativeMethods+MSG* msg, System.Runtime.InteropServices.HandleRef hwnd, System.Int32 msgMin, System.Int32 msgMax, System.Int32 remove)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.PeekMessage' has not been implemented!");
    //    }

    //    public static System.IntPtr SetTimer(System.Runtime.InteropServices.HandleRef hWnd, System.Runtime.InteropServices.HandleRef nIDEvent, System.Int32 uElapse, System.Runtime.InteropServices.HandleRef lpTimerProc)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetTimer' has not been implemented!");
    //    }

    //    public static System.Boolean KillTimer(System.Runtime.InteropServices.HandleRef hwnd, System.Runtime.InteropServices.HandleRef idEvent)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.KillTimer' has not been implemented!");
    //    }

    //    public static System.Boolean TranslateMessage(Microsoft.Win32.NativeMethods+MSG* msg)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.TranslateMessage' has not been implemented!");
    //    }

    //    public static System.Boolean WTSRegisterSessionNotification(System.Runtime.InteropServices.HandleRef hWnd, System.Int32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.WTSRegisterSessionNotification' has not been implemented!");
    //    }

    //    public static System.Boolean WTSUnRegisterSessionNotification(System.Runtime.InteropServices.HandleRef hWnd)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.WTSUnRegisterSessionNotification' has not been implemented!");
    //    }

    //    public static System.Int32 LookupAccountSid(System.String systemName, System.Byte[] pSid, System.Text.StringBuilder szUserName, System.Int32* userNameSize, System.Text.StringBuilder szDomainName, System.Int32* domainNameSize, System.Int32* eUse)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.LookupAccountSid' has not been implemented!");
    //    }

    //    public static System.Int32 GetModuleFileName(System.Runtime.InteropServices.HandleRef hModule, System.Text.StringBuilder buffer, System.Int32 length)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetModuleFileName' has not been implemented!");
    //    }

    //    public static System.Boolean ReportEvent(System.Runtime.InteropServices.SafeHandle hEventLog, System.Int16 type, System.UInt16 category, System.UInt32 eventID, System.Byte[] userSID, System.Int16 numStrings, System.Int32 dataLen, System.Runtime.InteropServices.HandleRef strings, System.Byte[] rawData)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReportEvent' has not been implemented!");
    //    }

    //    public static System.Boolean ClearEventLog(System.Runtime.InteropServices.SafeHandle hEventLog, System.Runtime.InteropServices.HandleRef lpctstrBackupFileName)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ClearEventLog' has not been implemented!");
    //    }

    //    public static System.Boolean GetNumberOfEventLogRecords(System.Runtime.InteropServices.SafeHandle hEventLog, System.Int32* count)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetNumberOfEventLogRecords' has not been implemented!");
    //    }

    //    public static System.Boolean GetOldestEventLogRecord(System.Runtime.InteropServices.SafeHandle hEventLog, System.Int32* number)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetOldestEventLogRecord' has not been implemented!");
    //    }

    //    public static System.Boolean ReadEventLog(System.Runtime.InteropServices.SafeHandle hEventLog, System.Int32 dwReadFlags, System.Int32 dwRecordOffset, System.Byte[] buffer, System.Int32 numberOfBytesToRead, System.Int32* bytesRead, System.Int32* minNumOfBytesNeeded)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReadEventLog' has not been implemented!");
    //    }

    //    public static System.Boolean NotifyChangeEventLog(System.Runtime.InteropServices.SafeHandle hEventLog, Microsoft.Win32.SafeHandles.SafeWaitHandle hEvent)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.NotifyChangeEventLog' has not been implemented!");
    //    }

    //    public static Microsoft.Win32.SafeHandles.SafeFileHandle CreateFile(System.String lpFileName, System.Int32 dwDesiredAccess, System.Int32 dwShareMode, System.IntPtr securityAttrs, System.Int32 dwCreationDisposition, System.Int32 dwFlagsAndAttributes, System.IntPtr hTemplateFile)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.CreateFile' has not been implemented!");
    //    }

    //    public static System.Boolean GetCommState(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, Microsoft.Win32.UnsafeNativeMethods+DCB* lpDCB)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetCommState' has not been implemented!");
    //    }

    //    public static System.Boolean SetCommState(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, Microsoft.Win32.UnsafeNativeMethods+DCB* lpDCB)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetCommState' has not been implemented!");
    //    }

    //    public static System.Boolean GetCommModemStatus(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32* lpModemStat)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetCommModemStatus' has not been implemented!");
    //    }

    //    public static System.Boolean SetupComm(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32 dwInQueue, System.Int32 dwOutQueue)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetupComm' has not been implemented!");
    //    }

    //    public static System.Boolean SetCommTimeouts(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, Microsoft.Win32.UnsafeNativeMethods+COMMTIMEOUTS* lpCommTimeouts)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetCommTimeouts' has not been implemented!");
    //    }

    //    public static System.Boolean SetCommBreak(Microsoft.Win32.SafeHandles.SafeFileHandle hFile)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetCommBreak' has not been implemented!");
    //    }

    //    public static System.Boolean ClearCommBreak(Microsoft.Win32.SafeHandles.SafeFileHandle hFile)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ClearCommBreak' has not been implemented!");
    //    }

    //    public static System.Boolean ClearCommError(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32* lpErrors, Microsoft.Win32.UnsafeNativeMethods+COMSTAT* lpStat)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ClearCommError' has not been implemented!");
    //    }

    //    public static System.Boolean ClearCommError(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32* lpErrors, System.IntPtr lpStat)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ClearCommError' has not been implemented!");
    //    }

    //    public static System.Boolean PurgeComm(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.UInt32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.PurgeComm' has not been implemented!");
    //    }

    //    public static System.Boolean FlushFileBuffers(Microsoft.Win32.SafeHandles.SafeFileHandle hFile)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.FlushFileBuffers' has not been implemented!");
    //    }

    //    public static System.Boolean GetCommProperties(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, Microsoft.Win32.UnsafeNativeMethods+COMMPROP* lpCommProp)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetCommProperties' has not been implemented!");
    //    }

    //    public static System.Int32 ReadFile(Microsoft.Win32.SafeHandles.SafeFileHandle handle, System.Byte* bytes, System.Int32 numBytesToRead, System.IntPtr numBytesRead, System.Threading.NativeOverlapped* overlapped)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReadFile' has not been implemented!");
    //    }

    //    public static System.Int32 ReadFile(Microsoft.Win32.SafeHandles.SafeFileHandle handle, System.Byte* bytes, System.Int32 numBytesToRead, System.Int32* numBytesRead, System.IntPtr overlapped)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.ReadFile' has not been implemented!");
    //    }

    //    public static System.Int32 WriteFile(Microsoft.Win32.SafeHandles.SafeFileHandle handle, System.Byte* bytes, System.Int32 numBytesToWrite, System.IntPtr numBytesWritten, System.Threading.NativeOverlapped* lpOverlapped)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.WriteFile' has not been implemented!");
    //    }

    //    public static System.Int32 WriteFile(Microsoft.Win32.SafeHandles.SafeFileHandle handle, System.Byte* bytes, System.Int32 numBytesToWrite, System.Int32* numBytesWritten, System.IntPtr lpOverlapped)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.WriteFile' has not been implemented!");
    //    }

    //    public static System.Int32 GetFileType(Microsoft.Win32.SafeHandles.SafeFileHandle hFile)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetFileType' has not been implemented!");
    //    }

    //    public static System.Boolean EscapeCommFunction(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32 dwFunc)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.EscapeCommFunction' has not been implemented!");
    //    }

    //    public static System.Boolean WaitCommEvent(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32* lpEvtMask, System.Threading.NativeOverlapped* lpOverlapped)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.WaitCommEvent' has not been implemented!");
    //    }

    //    public static System.Boolean SetCommMask(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Int32 dwEvtMask)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.SetCommMask' has not been implemented!");
    //    }

    //    public static System.Boolean GetOverlappedResult(Microsoft.Win32.SafeHandles.SafeFileHandle hFile, System.Threading.NativeOverlapped* lpOverlapped, System.Int32* lpNumberOfBytesTransferred, System.Boolean bWait)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.GetOverlappedResult' has not been implemented!");
    //    }

    //    public static System.Int32 CoMarshalInterface(System.Object pStm, System.Guid* riid, System.IntPtr pv, System.Int32 dwDestContext, System.IntPtr pvDestContext, System.Int32 mshlflags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.CoMarshalInterface' has not been implemented!");
    //    }

    //    public static System.Int32 CoGetStandardMarshal(System.Guid* riid, System.IntPtr pv, System.Int32 dwDestContext, System.IntPtr pvDestContext, System.Int32 mshlflags, System.IntPtr* ppMarshal)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.CoGetStandardMarshal' has not been implemented!");
    //    }

    //    public static System.Int32 CoGetMarshalSizeMax(System.Int32* pulSize, System.Guid* riid, System.IntPtr pv, System.Int32 dwDestContext, System.IntPtr pvDestContext, System.Int32 mshlflags)
    //    {
    //        throw new System.NotImplementedException("Method 'Microsoft.Win32.UnsafeNativeMethods.CoGetMarshalSizeMax' has not been implemented!");
    //    }
    //}
}
