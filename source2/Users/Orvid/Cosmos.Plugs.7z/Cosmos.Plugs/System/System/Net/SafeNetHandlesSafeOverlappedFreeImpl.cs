namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.SafeNetHandlesSafeOverlappedFree), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+SafeNetHandlesSafeOverlappedFreeImpl
    //{

    //    public static System.Net.SafeOverlappedFree LocalAlloc(System.Int32 uFlags, System.UIntPtr sizetdwBytes)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandlesSafeOverlappedFree.LocalAlloc' has not been implemented!");
    //    }
    //}
}
