namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.NativeNTSSPI), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+NativeNTSSPIImpl
    //{

    //    public static System.Int32 EncryptMessage(System.Net.SSPIHandle* contextHandle, System.UInt32 qualityOfProtection, System.Net.SecurityBufferDescriptor inputOutput, System.UInt32 sequenceNumber)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+NativeNTSSPI.EncryptMessage' has not been implemented!");
    //    }

    //    public static System.Int32 DecryptMessage(System.Net.SSPIHandle* contextHandle, System.Net.SecurityBufferDescriptor inputOutput, System.UInt32 sequenceNumber, System.UInt32* qualityOfProtection)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+NativeNTSSPI.DecryptMessage' has not been implemented!");
    //    }
    //}
}
