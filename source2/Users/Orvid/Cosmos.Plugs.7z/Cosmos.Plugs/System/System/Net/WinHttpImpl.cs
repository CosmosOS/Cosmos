namespace Cosmos.Plugs
{
    ////[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.WinHttp), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    ////public static class System_Net_UnsafeNclNativeMethods+WinHttpImpl
    ////{

    ////    public static System.Boolean WinHttpCloseHandle(System.IntPtr httpSession)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpCloseHandle' has not been implemented!");
    ////    }

    ////    public static System.Net.SafeInternetHandle WinHttpOpen(System.String userAgent, System.Net.UnsafeNclNativeMethods+WinHttp+AccessType accessType, System.String proxyName, System.String proxyBypass, System.Int32 dwFlags)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpOpen' has not been implemented!");
    ////    }

    ////    public static System.Boolean WinHttpSetTimeouts(System.Net.SafeInternetHandle session, System.Int32 resolveTimeout, System.Int32 connectTimeout, System.Int32 sendTimeout, System.Int32 receiveTimeout)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpSetTimeouts' has not been implemented!");
    ////    }

    ////    public static System.Boolean WinHttpDetectAutoProxyConfigUrl(System.Net.UnsafeNclNativeMethods+WinHttp+AutoDetectType autoDetectFlags, System.Net.SafeGlobalFree* autoConfigUrl)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpDetectAutoProxyConfigUrl' has not been implemented!");
    ////    }

    ////    public static System.Boolean WinHttpGetIEProxyConfigForCurrentUser(System.Net.UnsafeNclNativeMethods+WinHttp+WINHTTP_CURRENT_USER_IE_PROXY_CONFIG* proxyConfig)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpGetIEProxyConfigForCurrentUser' has not been implemented!");
    ////    }

    ////    public static System.Boolean WinHttpGetProxyForUrl(System.Net.SafeInternetHandle session, System.String url, System.Net.UnsafeNclNativeMethods+WinHttp+WINHTTP_AUTOPROXY_OPTIONS* autoProxyOptions, System.Net.UnsafeNclNativeMethods+WinHttp+WINHTTP_PROXY_INFO* proxyInfo)
    ////    {
    ////        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinHttp.WinHttpGetProxyForUrl' has not been implemented!");
    ////    }
    ////}
}
