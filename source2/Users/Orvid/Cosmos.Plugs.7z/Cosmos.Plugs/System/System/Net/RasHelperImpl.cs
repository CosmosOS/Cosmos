namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.RasHelper), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+RasHelperImpl
    //{

    //    public static System.UInt32 RasEnumConnections(System.Net.UnsafeNclNativeMethods+RasHelper+RASCONN[] lprasconn, System.UInt32* lpcb, System.UInt32* lpcConnections)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RasHelper.RasEnumConnections' has not been implemented!");
    //    }

    //    public static System.UInt32 RasConnectionNotification(System.IntPtr hrasconn, Microsoft.Win32.SafeHandles.SafeWaitHandle hEvent, System.UInt32 dwFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RasHelper.RasConnectionNotification' has not been implemented!");
    //    }

    //    public static System.UInt32 RasGetConnectStatus(System.IntPtr hrasconn, System.Net.UnsafeNclNativeMethods+RasHelper+RASCONNSTATUS* lprasconnstatus)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RasHelper.RasGetConnectStatus' has not been implemented!");
    //    }
    //}
}
