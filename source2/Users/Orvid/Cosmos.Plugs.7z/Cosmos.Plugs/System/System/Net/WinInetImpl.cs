namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.WinInet), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+WinInetImpl
    //{

    //    public static System.Boolean DetectAutoProxyUrl(System.Text.StringBuilder autoProxyUrl, System.Int32 autoProxyUrlLength, System.Int32 detectFlags)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+WinInet.DetectAutoProxyUrl' has not been implemented!");
    //    }
    //}
}
