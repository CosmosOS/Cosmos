namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.SafeNetHandles_SECURITY), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+SafeNetHandles_SECURITYImpl
    //{

    //    public static System.Int32 FreeContextBuffer(System.IntPtr contextBuffer)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.FreeContextBuffer' has not been implemented!");
    //    }

    //    public static System.Int32 FreeCredentialsHandle(System.Net.SSPIHandle* handlePtr)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.FreeCredentialsHandle' has not been implemented!");
    //    }

    //    public static System.Int32 DeleteSecurityContext(System.Net.SSPIHandle* handlePtr)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.DeleteSecurityContext' has not been implemented!");
    //    }

    //    public static System.Int32 AcceptSecurityContext(System.Net.SSPIHandle* credentialHandle, System.Void* inContextPtr, System.Net.SecurityBufferDescriptor inputBuffer, System.Net.ContextFlags inFlags, System.Net.Endianness endianness, System.Net.SSPIHandle* outContextPtr, System.Net.SecurityBufferDescriptor outputBuffer, System.Net.ContextFlags* attributes, System.Int64* timeStamp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.AcceptSecurityContext' has not been implemented!");
    //    }

    //    public static System.Int32 QueryContextAttributesW(System.Net.SSPIHandle* contextHandle, System.Net.ContextAttribute attribute, System.Void* buffer)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.QueryContextAttributesW' has not been implemented!");
    //    }

    //    public static System.Int32 InitializeSecurityContextW(System.Net.SSPIHandle* credentialHandle, System.Void* inContextPtr, System.Byte* targetName, System.Net.ContextFlags inFlags, System.Int32 reservedI, System.Net.Endianness endianness, System.Net.SecurityBufferDescriptor inputBuffer, System.Int32 reservedII, System.Net.SSPIHandle* outContextPtr, System.Net.SecurityBufferDescriptor outputBuffer, System.Net.ContextFlags* attributes, System.Int64* timeStamp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.InitializeSecurityContextW' has not been implemented!");
    //    }

    //    public static System.Int32 EnumerateSecurityPackagesW(System.Int32* pkgnum, System.Net.SafeFreeContextBuffer_SECURITY* handle)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.EnumerateSecurityPackagesW' has not been implemented!");
    //    }

    //    public static System.Int32 AcquireCredentialsHandleW(System.String principal, System.String moduleName, System.Int32 usage, System.Void* logonID, System.IntPtr zero, System.Void* keyCallback, System.Void* keyArgument, System.Net.SSPIHandle* handlePtr, System.Int64* timeStamp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.AcquireCredentialsHandleW' has not been implemented!");
    //    }

    //    public static System.Int32 AcquireCredentialsHandleW(System.String principal, System.String moduleName, System.Int32 usage, System.Void* logonID, System.Net.SecureCredential* authData, System.Void* keyCallback, System.Void* keyArgument, System.Net.SSPIHandle* handlePtr, System.Int64* timeStamp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.AcquireCredentialsHandleW' has not been implemented!");
    //    }

    //    public static System.Int32 CompleteAuthToken(System.Void* inContextPtr, System.Net.SecurityBufferDescriptor inputBuffers)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.CompleteAuthToken' has not been implemented!");
    //    }

    //    public static System.Int32 AcquireCredentialsHandleW(System.String principal, System.String moduleName, System.Int32 usage, System.Void* logonID, System.Net.AuthIdentity* authdata, System.Void* keyCallback, System.Void* keyArgument, System.Net.SSPIHandle* handlePtr, System.Int64* timeStamp)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+SafeNetHandles_SECURITY.AcquireCredentialsHandleW' has not been implemented!");
    //    }
    //}
}
