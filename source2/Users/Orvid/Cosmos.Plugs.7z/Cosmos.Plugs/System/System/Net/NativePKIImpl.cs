namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.NativePKI), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+NativePKIImpl
    //{

    //    public static System.Int32 CertVerifyCertificateChainPolicy(System.IntPtr policy, System.Net.SafeFreeCertChain chainContext, System.Net.ChainPolicyParameter* cpp, System.Net.ChainPolicyStatus* ps)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+NativePKI.CertVerifyCertificateChainPolicy' has not been implemented!");
    //    }
    //}
}
