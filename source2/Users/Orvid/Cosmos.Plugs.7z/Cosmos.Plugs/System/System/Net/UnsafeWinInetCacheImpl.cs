namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.UnsafeWinInetCache), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+UnsafeWinInetCacheImpl
    //{

    //    public static System.Boolean CreateUrlCacheEntryW(System.String urlName, System.Int32 expectedFileSize, System.String fileExtension, System.Text.StringBuilder fileName, System.Int32 dwReserved)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.CreateUrlCacheEntryW' has not been implemented!");
    //    }

    //    public static System.Boolean CommitUrlCacheEntryW(System.String urlName, System.String localFileName, System.Net.Cache._WinInetCache+FILETIME expireTime, System.Net.Cache._WinInetCache+FILETIME lastModifiedTime, System.Net.Cache._WinInetCache+EntryType EntryType, System.Byte* headerInfo, System.Int32 headerSizeTChars, System.String fileExtension, System.String originalUrl)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.CommitUrlCacheEntryW' has not been implemented!");
    //    }

    //    public static System.Boolean GetUrlCacheEntryInfoW(System.String urlName, System.Byte* entryPtr, System.Int32* bufferSz)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.GetUrlCacheEntryInfoW' has not been implemented!");
    //    }

    //    public static System.Boolean SetUrlCacheEntryInfoW(System.String lpszUrlName, System.Byte* EntryPtr, System.Net.Cache._WinInetCache+Entry_FC fieldControl)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.SetUrlCacheEntryInfoW' has not been implemented!");
    //    }

    //    public static System.Boolean DeleteUrlCacheEntryW(System.String urlName)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.DeleteUrlCacheEntryW' has not been implemented!");
    //    }

    //    public static System.Boolean UnlockUrlCacheEntryFileW(System.String urlName, System.Int32 dwReserved)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+UnsafeWinInetCache.UnlockUrlCacheEntryFileW' has not been implemented!");
    //    }
    //}
}
