namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.NetworkInformation.UnsafeWinINetNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Net_NetworkInformation_UnsafeWinINetNativeMethodsImpl
	{

		public static System.Boolean InternetGetConnectedState(System.UInt32* flags, System.UInt32 dwReserved)
		{
			throw new System.NotImplementedException("Method 'System.Net.NetworkInformation.UnsafeWinINetNativeMethods.InternetGetConnectedState' has not been implemented!");
		}
	}
}
