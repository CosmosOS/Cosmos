namespace Cosmos.Plugs
{
    //[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Net.RegistryHelper), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
    //public static class System_Net_UnsafeNclNativeMethods+RegistryHelperImpl
    //{

    //    public static System.UInt32 RegCloseKey(System.IntPtr key)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegCloseKey' has not been implemented!");
    //    }

    //    public static System.UInt32 RegOpenKeyEx(System.IntPtr key, System.String subKey, System.UInt32 ulOptions, System.UInt32 samDesired, System.Net.SafeRegistryHandle* resultSubKey)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegOpenKeyEx' has not been implemented!");
    //    }

    //    public static System.UInt32 RegOpenKeyEx(System.Net.SafeRegistryHandle key, System.String subKey, System.UInt32 ulOptions, System.UInt32 samDesired, System.Net.SafeRegistryHandle* resultSubKey)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegOpenKeyEx' has not been implemented!");
    //    }

    //    public static System.UInt32 RegNotifyChangeKeyValue(System.Net.SafeRegistryHandle key, System.Boolean watchSubTree, System.UInt32 notifyFilter, Microsoft.Win32.SafeHandles.SafeWaitHandle regEvent, System.Boolean async)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegNotifyChangeKeyValue' has not been implemented!");
    //    }

    //    public static System.UInt32 RegOpenCurrentUser(System.UInt32 samDesired, System.Net.SafeRegistryHandle* resultKey)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegOpenCurrentUser' has not been implemented!");
    //    }

    //    public static System.UInt32 RegQueryValueEx(System.Net.SafeRegistryHandle key, System.String valueName, System.IntPtr reserved, System.UInt32* type, System.Byte[] data, System.UInt32* size)
    //    {
    //        throw new System.NotImplementedException("Method 'System.Net.UnsafeNclNativeMethods+RegistryHelper.RegQueryValueEx' has not been implemented!");
    //    }
    //}
}
