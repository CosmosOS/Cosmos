namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Diagnostics.SharedUtils), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Diagnostics_SharedUtilsImpl
	{

		public static System.Int32 WaitForSingleObjectDontCallThis(Microsoft.Win32.SafeHandles.SafeWaitHandle handle, System.Int32 timeout)
		{
			throw new System.NotImplementedException("Method 'System.Diagnostics.SharedUtils.WaitForSingleObjectDontCallThis' has not been implemented!");
		}
	}
}
