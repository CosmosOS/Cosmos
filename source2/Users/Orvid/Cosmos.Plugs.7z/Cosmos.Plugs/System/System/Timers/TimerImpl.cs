namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Timers.Timer), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Timers_TimerImpl
	{

		public static System.Void GetSystemTimeAsFileTime(System.Timers.Timer+FILE_TIME* lpSystemTimeAsFileTime)
		{
			throw new System.NotImplementedException("Method 'System.Timers.Timer.GetSystemTimeAsFileTime' has not been implemented!");
		}
	}
}
