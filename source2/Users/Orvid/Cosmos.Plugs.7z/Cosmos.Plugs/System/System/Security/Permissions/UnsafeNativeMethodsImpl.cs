namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Security.Permissions.UnsafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Security_Permissions_ResourcePermissionBase+UnsafeNativeMethodsImpl
	{

		public static System.Boolean GetComputerName(System.Text.StringBuilder lpBuffer, System.Int32* nSize)
		{
			throw new System.NotImplementedException("Method 'System.Security.Permissions.ResourcePermissionBase+UnsafeNativeMethods.GetComputerName' has not been implemented!");
		}
	}
}
