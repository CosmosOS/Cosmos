namespace Cosmos.Plugs
{
	[Cosmos.IL2CPU.Plugs.Plug(Target = typeof(System.Media.SafeNativeMethods), TargetFramework = Cosmos.IL2CPU.Plugs.FrameworkVersion.v4_0)]
	public static class System_Media_SystemSound+SafeNativeMethodsImpl
	{

		public static System.Boolean MessageBeep(System.Int32 type)
		{
			throw new System.NotImplementedException("Method 'System.Media.SystemSound+SafeNativeMethods.MessageBeep' has not been implemented!");
		}
	}
}
